@extends('masterpage')

@section('content')
                <!--my table begin-->
                <button type="submit" class="btn btn-primary"  href="#" data-toggle="modal" data-target="#addProfil"><i class="fas fa-plus" style="margin-right:5px"></i>Nouveau profil</button>
            
                <div class="row" style="margin-top:80px">
            <div class="col-md-12">
                
                <div class="form-content" >    

           <h3 class="text-center">Liste des profils</h3>

             <!--searchbar-->
             <div class="container input-group rounded" style="margin-bottom:7px;padding-left:80px;padding-right:80px">
                <input type="search" id="secsearchbar" class="form-control rounded" placeholder="Que cherchez-vous ? " aria-label="Search" aria-describedby="search-addon"/>
                <button class="btn btn-primary" style="border-top-right-radius:20px;border-bottom-right-radius:20px;border-top-left-radius:0px;border-bottom-left-radius:0px"  disabled>
                  <i class="fas fa-search"></i>
                </button>
              </div>
        
    
           <table class="table" >
           <thead class="thead thead-dark ">
             <tr>
             <th>ID-PROFIL</th>
             <th>PROFIL</th>
             <th>ACTION</th>
             </tr>
             </thead>
             <tbody id="tabprofils">
           
             </tbody>
           </table>
           
        </div>
    
        </div>

    </div>
<!--my table end-->

         <!-- Footer -->
         <footer class="sticky-footer bg-white">
           <div class="container my-auto">
               <div class="copyright text-center my-auto">
                   <span>Copyright &copy; Ramex 2021</span>
               </div>
           </div>
         </footer>
        <!-- End of Footer -->

                </div>
                <!-- /.container-fluid -->
            
            </div>
            <!-- End of Main Content -->

 

          

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
               
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4"> <img src="{{ asset('customAuth/images/logout.jpg') }}" alt="" style="width:130px;height:130px"></div>
                        <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h5>voulez-vous vraiment vous déconnecter ?</h5></center></div>
                    </div>

                    
                     <center>  
                        <a class="btn btn-primary " href="{{ route('logout') }}"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            {{ __('Se Déconnecter') }}</a>
                                            <button class="btn btn-secondary " type="button" data-dismiss="modal">Quitter</button>
                                        </center>
                                            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                            @csrf
                                        </form>
                                    
                </div>
                
            </div>
        </div>
    </div>




     <!--success modal begin-->
        <!-- Modal -->
        <div class="modal fade" id="success_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document" >
              <div class="modal-content" style="background-color:rgb(35, 220, 61);border-radius:40px;color:white">
                <div class="modal-body" >
               
                  <div class="row">
                      <div class="col-md-4"> <img src="{{ asset('customAuth/images/check.gif') }}" alt=""></div>
                      <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Cette opération est terminée avec succès</h3></center></div>
                  </div>
                
                </div>
    
              </div>
            </div>
          </div>
      <!--susccess modal end-->

    


       <!--delete profil modal-->
    <div class="modal fade" id="deleteProfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color:#ff0f0f;border-radius:20px;color:white;height:250px"> 

            <form id="deleteFormID">
             <div class="modal-body"> 
             {{csrf_field()}}
             {{method_field('delete')}}
             <input type="hidden" name="iddelprofil" id="iddelprofil" value="">
             <div class="row">
                <div class="col-md-4"> <img src="{{ asset('customAuth/images/warning.gif') }}" alt="" style="width:150px;height:150px"></div>
                <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Voulez vous vraiment supprimer ce profil?</h3></center></div>
            </div>
        <!--     <i class="fas fa-exclamation-triangle" style="font-size:30px; color:#ffcc00"></i> Voulez vous vraiment supprimer cet utilisateur? -->
        <center>
            <button type="submit" id="delete" class="btn btn-danger btn-lg" >Supprimer</button>
            <button class="btn btn-secondary btn-lg" type="button" data-dismiss="modal">Quitter</button>
            </center>   
    </div>
           
            
            </form>
            
        </div>
    </div>
</div>




 <!--add profil modal begin-->
    
<!-- Modal -->
<div class="modal fade" id="addProfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#4e73df;color:white">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter un nouveau profil</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="color:white">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!--begin of my form-->
        <div class="col-lg-12">
    
                    <form id="addform" class="profil" enctype="multipart/form-data">
                     @csrf


                        <div class="form-group">
                                <input id="profil" type="text" class="form-control"
                                 name="profil" value="{{ old('profil') }}" placeholder="Veuillez entrer un profil" autocomplete="profil">
                                <small id="profil_error" class="form-text text-danger"></small>
                        </div>

                <div class="form-group">
                    <label for="">Veuillez selectionner les droits</label>
                 <div class="overflow-auto" style="max-height: 150px;padding-left:.3rem">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="showclient">
                            <label class="form-check-label" for="showclient">
                              Afficher la liste des clients
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="addclient">
                            <label class="form-check-label" for="addclient">
                              Ajouter un client
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="updateclient">
                            <label class="form-check-label" for="updateclient">
                              Modifier un client
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="deleteclient">
                            <label class="form-check-label" for="deleteclient">
                              Supprimer un client
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="showcommand">
                            <label class="form-check-label" for="showcommand">
                                Afficher la liste des demandes
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="addcommand">
                            <label class="form-check-label" for="addcommand">
                              Ajouter une demande
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="updatecommandbef">
                            <label class="form-check-label" for="updatecommandbef">
                              Modifier une demande avant l'affectation
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="updatecommandaf">
                            <label class="form-check-label" for="updatecommandaf">
                              Modifier une demande après l'affectation
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="deletecommand">
                            <label class="form-check-label" for="deletecommand">
                              Supprimer une demande
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="assigncommand">
                            <label class="form-check-label" for="assigncommand">
                              Affecter une demande
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="confirmcommand">
                            <label class="form-check-label" for="confirmcommand">
                              Confirmer une demande
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="cancelcommand">
                            <label class="form-check-label" for="cancelcommand">
                              Annuler une demande
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="manageprofils">
                            <label class="form-check-label" for="manageprofils">
                              Gérer les profils
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="manageusers">
                            <label class="form-check-label" for="manageusers">
                              Gérer les utilisateurs
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="managemotifs">
                            <label class="form-check-label" for="managemotifs">
                              Gérer les motifs
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="manageagences">
                            <label class="form-check-label" for="manageagences">
                              Gérer les agences
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="managesectors">
                            <label class="form-check-label" for="managesectors">
                              Gérer les secteurs
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="managecommercials">
                            <label class="form-check-label" for="managecommercials">
                              Gérer les commerciaux
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="usershistory">
                            <label class="form-check-label" for="usershistory">
                              Afficher l'historique des utilisateurs
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="clientshistory">
                            <label class="form-check-label" for="clientshistory">
                                Afficher l'historique des clients
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="commandshistory">
                            <label class="form-check-label" for="commandshistory">
                                Afficher l'historique des demandes
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="generatesheets">
                            <label class="form-check-label" for="generatesheets">
                                Générer les fichiers excel
                            </label>
                          </div>
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="" id="dashboard">
                            <label class="form-check-label" for="dashboard">
                                Tableau de bord
                            </label>
                          </div>
                 </div>
                </div>

                      <center> 
                          <button type="submit" id="save" class="btn btn-primary">Ajouter </button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Quitter</button>
                    </center>
                    </form>
                
            </div>
        <!--end of my form-->
      </div>
    </div>
  </div>
</div>
    <!--add profil modal end-->


    <!--edit profil modal begin-->
<!-- Modal -->
<div class="modal fade" id="editProfil" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#4e73df; color:white">
        <h5 class="modal-title" id="exampleModalLabel">Modifier un profil</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="color:white">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!--begin of my form-->
        <div class="col-lg-12">
    
                    <form id="editform" enctype="multipart/form-data">
                     @csrf
                     {{method_field('PUT')}}
                     <input type="hidden" name="id" id="id">
                   

                     <div class="form-group">
                      <input id="modprofil" type="text" class="form-control"
                       name="modprofil" value="{{ old('modprofil') }}" placeholder="Veuillez entrer un profil" autocomplete="modprofil">
                      <small id="modprofil_error" class="form-text text-danger"></small>
              </div>

      <div class="form-group">
          <label for="">Veuillez selectionner les droits</label>
       <div class="overflow-auto" style="max-height: 150px;padding-left:.3rem">
              <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modshowclient">
                  <label class="form-check-label" for="modshowclient">
                    Afficher la liste des clients
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modaddclient">
                  <label class="form-check-label" for="modaddclient">
                    Ajouter un client
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modupdateclient">
                  <label class="form-check-label" for="modupdateclient">
                    Modifier un client
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="moddeleteclient">
                  <label class="form-check-label" for="moddeleteclient">
                    Supprimer un client
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modshowcommand">
                  <label class="form-check-label" for="modshowcommand">
                      Afficher la liste des demandes
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modaddcommand">
                  <label class="form-check-label" for="modaddcommand">
                    Ajouter une demande
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modupdatecommandbef">
                  <label class="form-check-label" for="modupdatecommandbef">
                    Modifier une demande avant l'affectation
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modupdatecommandaf">
                  <label class="form-check-label" for="modupdatecommandaf">
                    Modifier une demande après l'affectation
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="moddeletecommand">
                  <label class="form-check-label" for="moddeletecommand">
                    Supprimer une demande
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modassigncommand">
                  <label class="form-check-label" for="modassigncommand">
                    Affecter une demande
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modconfirmcommand">
                  <label class="form-check-label" for="modconfirmcommand">
                    Confirmer une demande
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modcancelcommand">
                  <label class="form-check-label" for="modcancelcommand">
                    Annuler une demande
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modmanageprofils">
                  <label class="form-check-label" for="modmanageprofils">
                    Gérer les profils
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modmanageusers">
                  <label class="form-check-label" for="modmanageusers">
                    Gérer les utilisateurs
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modmanagemotifs">
                  <label class="form-check-label" for="modmanagemotifs">
                    Gérer les motifs
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modmanageagences">
                  <label class="form-check-label" for="modmanageagences">
                    Gérer les agences
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modmanagesectors">
                  <label class="form-check-label" for="modmanagesectors">
                    Gérer les secteurs
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modmanagecommercials">
                  <label class="form-check-label" for="modmanagecommercials">
                    Gérer les commerciaux
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modusershistory">
                  <label class="form-check-label" for="modusershistory">
                    Afficher l'historique des utilisateurs
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modclientshistory">
                  <label class="form-check-label" for="modclientshistory">
                      Afficher l'historique des clients
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modcommandshistory">
                  <label class="form-check-label" for="modcommandshistory">
                      Afficher l'historique des demandes
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="modgeneratesheets">
                  <label class="form-check-label" for="modgeneratesheets">
                      Générer les fichiers excel
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="moddashboard">
                  <label class="form-check-label" for="moddashboard">
                      Tableau de bord
                  </label>
                </div>
       </div>
      </div>
 
        
                      <center>
                        <button type="submit" class="btn btn-primary">Modifier </button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Quitter</button>
                        </center>
                    </form>
                
            </div>
        <!--end of my form-->
      </div>
    </div>
  </div>
</div>
    <!--edit user modal end-->



      <!--edit user modal begin-->
<!-- Modal -->
<div class="modal fade" id="changesettingsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#4e73df; color:white">
          <h5 class="modal-title" id="exampleModalLabel">Modifier votre paramètres</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color:white">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!--begin of my form-->
          <div class="col-lg-12">
      
                      <form id="editform2" enctype="multipart/form-data">
                       @csrf
                       {{method_field('PUT')}}
                       
                          <div class="form-group">
                                  <label for="">Changer votre image de profil</label>
                                  <input id="modimage2" type="file" class="form-control"
                                   name="modimage2">
                          </div>
  
                         
  
                          <div class="form-group">
                            <label for="">Changer votre mot de passe</label>
                                   <input id="modpassword2" type="password" class="form-control form-control-user @error('password') is-invalid @enderror"
                                    name="modpassword2" placeholder="Nouveau mot de passe" autocomplete="Nouveau mot de passe">
                                    <small id="modpassword_error" class="form-text text-danger"></small>
                          </div>
  
                        <center>
                          <button type="submit" class="btn btn-primary">Enregistrer </button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                        </center>
                      </form>
                  
              </div>
          <!--end of my form-->
        </div>
      </div>
    </div>
  </div>
      <!--edit user modal end-->




    <!-- Bootstrap core JavaScript-->
    <script src="{{asset('customAuth/vendor/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('customAuth/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{asset('customAuth/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{asset('customAuth/js/sb-admin-2.min.js')}}"></script>
    
    <!--script toastr-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


<!--Affichage dans la table-->
<script>
$(document).ready(function(){
    $.get("{{ route('AllProfils') }}", function(data, response){
                
                for (var i = 0; i < data.length; i++) {
                    var line='<tr class="'+data[i].id+'"><td>'+data[i].id+'</td><td>'+data[i].profil+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                    $('#tabprofils').append(line);
                }
              //  var pagination= data.links;
              //  $('.pag').append(pagination);
            });
});
</script>
<!--addprofil ajax code-->
<script>
        $(document).ready( function(){

             /***************/
            //  if ($('input.form-check-input').is(':checked')){
            //      $('input.form-check-input').val(1);
            //  } else 
             
             $('input.form-check-input').val(0);

           
             $('#showclient').click(function() {
                if ($('#showclient').is(':checked')){
                    $('#showclient').val(1);
                } else{
                    $('#showclient').val(0);
                }
             });
             $('#addclient').click(function() {
                if ($('#addclient').is(':checked')){
                    $('#addclient').val(1);
                } else{
                    $('#addclient').val(0);
                }
             });
             $('#updateclient').click(function() {
                if ($('#updateclient').is(':checked')){
                    $('#updateclient').val(1);
                } else{
                    $('#updateclient').val(0);
                }
             });
             $('#deleteclient').click(function() {
                if ($('#deleteclient').is(':checked')){
                    $('#deleteclient').val(1);
                } else{
                    $('#deleteclient').val(0);
                }
             });
             $('#showcommand').click(function() {
                if ($('#showcommand').is(':checked')){
                    $('#showcommand').val(1);
                } else{
                    $('#showcommand').val(0);
                }
             });
             $('#addcommand').click(function() {
                if ($('#addcommand').is(':checked')){
                    $('#addcommand').val(1);
                } else{
                    $('#addcommand').val(0);
                }
             });
             $('#updatecommandbef').click(function() {
                if ($('#updatecommandbef').is(':checked')){
                    $('#updatecommandbef').val(1);
                } else{
                    $('#updatecommandbef').val(0);
                }
             });
             $('#updatecommandaf').click(function() {
                if ($('#updatecommandaf').is(':checked')){
                    $('#updatecommandaf').val(1);
                } else{
                    $('#updatecommandaf').val(0);
                }
             });
             $('#deletecommand').click(function() {
                if ($('#deletecommand').is(':checked')){
                    $('#deletecommand').val(1);
                } else{
                    $('#deletecommand').val(0);
                }
             });
             $('#assigncommand').click(function() {
                if ($('#assigncommand').is(':checked')){
                    $('#assigncommand').val(1);
                } else{
                    $('#assigncommand').val(0);
                }
             });
             $('#confirmcommand').click(function() {
                if ($('#confirmcommand').is(':checked')){
                    $('#confirmcommand').val(1);
                } else{
                    $('#confirmcommand').val(0);
                }
             });
             $('#cancelcommand').click(function() {
                if ($('#cancelcommand').is(':checked')){
                    $('#cancelcommand').val(1);
                } else{
                    $('#cancelcommand').val(0);
                }
             });
             $('#manageprofils').click(function() {
                if ($('#manageprofils').is(':checked')){
                    $('#manageprofils').val(1);
                } else{
                    $('#manageprofils').val(0);
                }
             });
             $('#manageusers').click(function() {
                if ($('#manageusers').is(':checked')){
                    $('#manageusers').val(1);
                } else{
                    $('#manageusers').val(0);
                }
             });
             $('#managemotifs').click(function() {
                if ($('#managemotifs').is(':checked')){
                    $('#managemotifs').val(1);
                } else{
                    $('#managemotifs').val(0);
                }
             });
             $('#manageagences').click(function() {
                if ($('#manageagences').is(':checked')){
                    $('#manageagences').val(1);
                } else{
                    $('#manageagences').val(0);
                }
             });
             $('#managesectors').click(function() {
                if ($('#managesectors').is(':checked')){
                    $('#managesectors').val(1);
                } else{
                    $('#managesectors').val(0);
                }
             });
             $('#managecommercials').click(function() {
                if ($('#managecommercials').is(':checked')){
                    $('#managecommercials').val(1);
                } else{
                    $('#managecommercials').val(0);
                }
             });
             $('#usershistory').click(function() {
                if ($('#usershistory').is(':checked')){
                    $('#usershistory').val(1);
                } else{
                    $('#usershistory').val(0);
                }
             });
             $('#clientshistory').click(function() {
                if ($('#clientshistory').is(':checked')){
                    $('#clientshistory').val(1);
                } else{
                    $('#clientshistory').val(0);
                }
             });
             $('#commandshistory').click(function() {
                if ($('#commandshistory').is(':checked')){
                    $('#commandshistory').val(1);
                } else{
                    $('#commandshistory').val(0);
                }
             });
             $('#generatesheets').click(function() {
                if ($('#generatesheets').is(':checked')){
                    $('#generatesheets').val(1);
                } else{
                    $('#generatesheets').val(0);
                }
             });
             $('#dashboard').click(function() {
                if ($('#dashboard').is(':checked')){
                    $('#dashboard').val(1);
                } else{
                    $('#dashboard').val(0);
                }
             });
              /**************/

            //submit
            $('#save').on('click',function(e){
              e.preventDefault();
              
              var mydata={
                  profil:$("#profil").val(),
                  showclient:$('#showclient').val(),
                  addclient:$('#addclient').val(),
                  updateclient:$('#updateclient').val(),
                  deleteclient:$('#deleteclient').val(),
                  showcommand:$('#showcommand').val(),
                  addcommand: $('#addcommand').val(),
                  updatecommandbef:$('#updatecommandbef').val(),
                  updatecommandaf:$('#updatecommandaf').val(),
                  deletecommand: $('#deletecommand').val(),
                  assigncommand:$('#assigncommand').val(),
                  confirmcommand:$('#confirmcommand').val(),
                  cancelcommand: $('#cancelcommand').val(),
                  manageprofils:$('#manageprofils').val(),
                  manageusers:$('#manageusers').val(),
                  managemotifs:$('#managemotifs').val(),
                  manageagences: $('#manageagences').val(),
                  managesectors:$('#managesectors').val(),
                  managecommercials: $('#managecommercials').val(),
                  usershistory:$('#usershistory').val(),
                  clientshistory:$('#clientshistory').val(),
                  commandshistory: $('#commandshistory').val(),
                  generatesheets:$('#generatesheets').val(),
                  dashboard:$('#dashboard').val(),

              }
              $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:"{{route('storeprofil')}}",
                data:mydata,
                //data:new FormData($('#addform').serialize()),
                success:function(data,response){
                    //console.log(response);
                    $('#addProfil').modal('hide');
                    $("#profil").val("");
                   // $('input.form-check-input').is(':unchecked');
                   $('.form-check-input').prop('checked', false);
                    $('#tabprofils').html('');
                    //alert(data.id);
                    for (var i = 0; i < data.length; i++) {
                    var line='<tr class="'+data[i].id+'"><td>'+data[i].id+'</td><td>'+data[i].profil+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                    $('#tabprofils').append(line);
                }
                   $('#success_modal').modal('show');

                   setTimeout(function() {
                       $('#success_modal').modal('hide');
                   }, 1000);
                 
                },
                error:function(error){
                    $("#motif_error").text("");
                    var response=$.parseJSON(error.responseText);
                    //alert(response.errors);
                    $.each(response.errors,function(key,val){
                       $("#"+key+"_error").text(val[0]);
                    });
                //  alert("erreur");
                }
              });
            });

          //  public ActionResult IndexAjax() { var data=AddToastMessage("Congratulations", "You made it all the way here!", ToastType.Success); 
        //return Json(data, JsonRequestBehavior.AllowGet);
        });


       
      </script>

    <!--Search bar-->
           <script>
           $(document).ready(function(){
           $("#searchbar").on("keyup", function() {
             var value = $(this).val().toLowerCase();
           $("#tabusers tr").filter(function() {
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
            });
            });
            </script>

     <!--modprofil ajax code-->       
     <script>
           $(document).ready(function(){
            
            $(document).on("click", "a.editbtn" , function() {
            $('#editProfil').modal('show');

            $tr=$(this).closest('tr');
            var data=$tr.children("td").map(function(){
                return $(this).text();
            }).get();

            $('#id').val(data[0]);
            $("#modprofil").val("");
            $id=data[0];
            $.get("{{ route('SelectedProfilById') }}",{id:$id}, function(data, response){
               //alert(data[0].profil);
                  $("#modprofil").val(data[0].profil);

              /***************/
             //part1
                if (data[0].show_client == 1){
                  $( "#modshowclient" ).prop( "checked", true );
                  $('#modshowclient').val(1);
                }else{
                  $( "#modshowclient" ).prop( "checked", false );
                  $('#modshowclient').val(0);
                }
             //part2
                $('#modshowclient').click(function() {
                if ($('#modshowclient').is(':checked')){
                    $('#modshowclient').val(1);
                } else{
                    $('#modshowclient').val(0);
                }
              });
                 //part1
                 if (data[0].add_client == 1){
                  $( "#modaddclient" ).prop( "checked", true );
                  $('#modaddclient').val(1);
                }else{
                  $( "#modaddclient" ).prop( "checked", false );
                  $('#modaddclient').val(0);
                }
             //part2
                $('#modaddclient').click(function() {
                if ($('#modaddclient').is(':checked')){
                    $('#modaddclient').val(1);
                } else{
                    $('#modaddclient').val(0);
                }
              });
                 //part1
                 if (data[0].update_client == 1){
                  $( "#modupdateclient" ).prop( "checked", true );
                  $('#modupdateclient').val(1);
                }else{
                  $( "#modupdateclient" ).prop( "checked", false );
                  $('#modupdateclient').val(0);
                }
             //part2
                $('#modupdateclient').click(function() {
                if ($('#modupdateclient').is(':checked')){
                    $('#modupdateclient').val(1);
                } else{
                    $('#modupdateclient').val(0);
                }
              });
                 //part1
                 if (data[0].delete_client == 1){
                  $( "#moddeleteclient" ).prop( "checked", true );
                  $('#moddeleteclient').val(1);
                }else{
                  $( "#moddeleteclient" ).prop( "checked", false );
                  $('#moddeleteclient').val(0);
                }
             //part2
                $('#moddeleteclient').click(function() {
                if ($('#moddeleteclient').is(':checked')){
                    $('#moddeleteclient').val(1);
                } else{
                    $('#moddeleteclient').val(0);
                }
              });
                 //part1
                 if (data[0].show_command == 1){
                  $( "#modshowcommand" ).prop( "checked", true );
                  $('#modshowcommand').val(1);
                }else{
                  $( "#modshowcommand" ).prop( "checked", false );
                  $('#modshowcommand').val(0);
                }
             //part2
                $('#modshowcommand').click(function() {
                if ($('#modshowcommand').is(':checked')){
                    $('#modshowcommand').val(1);
                } else{
                    $('#modshowcommand').val(0);
                }
              });
                 //part1
                 if (data[0].add_command == 1){
                  $( "#modaddcommand" ).prop( "checked", true );
                  $('#modaddcommand').val(1);
                }else{
                  $( "#modaddcommand" ).prop( "checked", false );
                  $('#modaddcommand').val(0);
                }
             //part2
                $('#modaddcommand').click(function() {
                if ($('#modaddcommand').is(':checked')){
                    $('#modaddcommand').val(1);
                } else{
                    $('#modaddcommand').val(0);
                }
              });
                 //part1
                 if (data[0].update_command == 1){
                  $( "#modupdatecommandbef" ).prop( "checked", true );
                  $('#modupdatecommandbef').val(1);
                }else{
                  $( "#modupdatecommandbef" ).prop( "checked", false );
                  $('#modupdatecommandbef').val(0);
                }
             //part2
                $('#modupdatecommandbef').click(function() {
                if ($('#modupdatecommandbef').is(':checked')){
                    $('#modupdatecommandbef').val(1);
                } else{
                    $('#modupdatecommandbef').val(0);
                }
              });
               //part1
               if (data[0].update2_command == 1){
                  $( "#modupdatecommandaf" ).prop( "checked", true );
                  $('#modupdatecommandaf').val(1);
                }else{
                  $( "#modupdatecommandaf" ).prop( "checked", false );
                  $('#modupdatecommandaf').val(0);
                }
             //part2
                $('#modupdatecommandaf').click(function() {
                if ($('#modupdatecommandaf').is(':checked')){
                    $('#modupdatecommandaf').val(1);
                } else{
                    $('#modupdatecommandaf').val(0);
                }
              });
                 //part1
                 if (data[0].delete_command == 1){
                  $( "#moddeletecommand" ).prop( "checked", true );
                  $('#moddeletecommand').val(1);
                }else{
                  $( "#moddeletecommand" ).prop( "checked", false );
                  $('#moddeletecommand').val(0);
                }
             //part2
                $('#moddeletecommand').click(function() {
                if ($('#moddeletecommand').is(':checked')){
                    $('#moddeletecommand').val(1);
                } else{
                    $('#moddeletecommand').val(0);
                }
              });
                 //part1
                 if (data[0].assign_command == 1){
                  $( "#modassigncommand" ).prop( "checked", true );
                  $('#modassigncommand').val(1);
                }else{
                  $( "#modassigncommand" ).prop( "checked", false );
                  $('#modassigncommand').val(0);
                }
             //part2
                $('#modassigncommand').click(function() {
                if ($('#modassigncommand').is(':checked')){
                    $('#modassigncommand').val(1);
                } else{
                    $('#modassigncommand').val(0);
                }
              });
                //part1
                if (data[0].confirm_command == 1){
                  $( "#modconfirmcommand" ).prop( "checked", true );
                  $('#modconfirmcommand').val(1);
                }else{
                  $( "#modconfirmcommand" ).prop( "checked", false );
                  $('#modconfirmcommand').val(0);
                }
             //part2
                $('#modconfirmcommand').click(function() {
                if ($('#modconfirmcommand').is(':checked')){
                    $('#modconfirmcommand').val(1);
                } else{
                    $('#modconfirmcommand').val(0);
                }
              });
                //part1
                if (data[0].cancel_command == 1){
                  $( "#modcancelcommand" ).prop( "checked", true );
                  $('#modcancelcommand').val(1);
                }else{
                  $( "#modcancelcommand" ).prop( "checked", false );
                  $('#modcancelcommand').val(0);
                }
             //part2
                $('#modcancelcommand').click(function() {
                if ($('#modcancelcommand').is(':checked')){
                    $('#modcancelcommand').val(1);
                } else{
                    $('#modcancelcommand').val(0);
                }
              });
               //part1
               if (data[0].manage_profils == 1){
                  $( "#modmanageprofils" ).prop( "checked", true );
                  $('#modmanageprofils').val(1);
                }else{
                  $( "#modmanageprofils" ).prop( "checked", false );
                  $('#modmanageprofils').val(0);
                }
             //part2
                $('#modmanageprofils').click(function() {
                if ($('#modmanageprofils').is(':checked')){
                    $('#modmanageprofils').val(1);
                } else{
                    $('#modmanageprofils').val(0);
                }
              });
                //part1
                if (data[0].manage_users == 1){
                  $( "#modmanageusers" ).prop( "checked", true );
                  $('#modmanageusers').val(1);
                }else{
                  $( "#modmanageusers" ).prop( "checked", false );
                  $('#modmanageusers').val(0);
                }
             //part2
                $('#modmanageusers').click(function() {
                if ($('#modmanageusers').is(':checked')){
                    $('#modmanageusers').val(1);
                } else{
                    $('#modmanageusers').val(0);
                }
              });
                 //part1
                 if (data[0].manage_users == 1){
                  $( "#modmanageusers" ).prop( "checked", true );
                  $('#modmanageusers').val(1);
                }else{
                  $( "#modmanageusers" ).prop( "checked", false );
                  $('#modmanageusers').val(0);
                }
             //part2
                $('#modmanageusers').click(function() {
                if ($('#modmanageusers').is(':checked')){
                    $('#modmanageusers').val(1);
                } else{
                    $('#modmanageusers').val(0);
                }
              });

               //part1
               if (data[0].manage_motifs == 1){
                  $( "#modmanagemotifs" ).prop( "checked", true );
                  $('#modmanagemotifs').val(1);
                }else{
                  $( "#modmanagemotifs" ).prop( "checked", false );
                  $('#modmanagemotifs').val(0);
                }
             //part2
                $('#modmanagemotifs').click(function() {
                if ($('#modmanagemotifs').is(':checked')){
                    $('#modmanagemotifs').val(1);
                } else{
                    $('#modmanagemotifs').val(0);
                }
              });

              //part1
              if (data[0].manage_agences == 1){
                  $( "#modmanageagences" ).prop( "checked", true );
                  $('#modmanageagences').val(1);
                }else{
                  $( "#modmanageagences" ).prop( "checked", false );
                  $('#modmanageagences').val(0);
                }
             //part2
                $('#modmanageagences').click(function() {
                if ($('#modmanageagences').is(':checked')){
                    $('#modmanageagences').val(1);
                } else{
                    $('#modmanageagences').val(0);
                }
              });

              //part1
              if (data[0].manage_sectors == 1){
                  $( "#modmanagesectors" ).prop( "checked", true );
                  $('#modmanagesectors').val(1);
                }else{
                  $( "#modmanagesectors" ).prop( "checked", false );
                  $('#modmanagesectors').val(0);
                }
             //part2
                $('#modmanagesectors').click(function() {
                if ($('#modmanagesectors').is(':checked')){
                    $('#modmanagesectors').val(1);
                } else{
                    $('#modmanagesectors').val(0);
                }
              });
                 //part1
              if (data[0].manage_commercials == 1){
                  $( "#modmanagecommercials" ).prop( "checked", true );
                  $('#modmanagecommercials').val(1);
                }else{
                  $( "#modmanagecommercials" ).prop( "checked", false );
                  $('#modmanagecommercials').val(0);
                }
             //part2
                $('#modmanagecommercials').click(function() {
                if ($('#modmanagecommercials').is(':checked')){
                    $('#modmanagecommercials').val(1);
                } else{
                    $('#modmanagecommercials').val(0);
                }
              });
                 //part1
              if (data[0].users_history == 1){
                  $( "#modusershistory" ).prop( "checked", true );
                  $('#modusershistory').val(1);
                }else{
                  $( "#modusershistory" ).prop( "checked", false );
                  $('#modusershistory').val(0);
                }
             //part2
                $('#modusershistory').click(function() {
                if ($('#modusershistory').is(':checked')){
                    $('#modusershistory').val(1);
                } else{
                    $('#modusershistory').val(0);
                }
              });
                 //part1
              if (data[0].clients_history == 1){
                  $( "#modclientshistory" ).prop( "checked", true );
                  $('#modclientshistory').val(1);
                }else{
                  $( "#modclientshistory" ).prop( "checked", false );
                  $('#modclientshistory').val(0);
                }
             //part2
                $('#modclientshistory').click(function() {
                if ($('#modclientshistory').is(':checked')){
                    $('#modclientshistory').val(1);
                } else{
                    $('#modclientshistory').val(0);
                }
              });
                 //part1
              if (data[0].commands_history == 1){
                  $( "#modcommandshistory" ).prop( "checked", true );
                  $('#modcommandshistory').val(1);
                }else{
                  $( "#modcommandshistory" ).prop( "checked", false );
                  $('#modcommandshistory').val(0);
                }
             //part2
                $('#modcommandshistory').click(function() {
                if ($('#modcommandshistory').is(':checked')){
                    $('#modcommandshistory').val(1);
                } else{
                    $('#modcommandshistory').val(0);
                }
              });

                 //part1
              if (data[0].generate_sheets == 1){
                  $( "#modgeneratesheets" ).prop( "checked", true );
                  $('#modgeneratesheets').val(1);
                }else{
                  $( "#modgeneratesheets" ).prop( "checked", false );
                  $('#modgeneratesheets').val(0);
                }
             //part2
                $('#modgeneratesheets').click(function() {
                if ($('#modgeneratesheets').is(':checked')){
                    $('#modgeneratesheets').val(1);
                } else{
                    $('#modgeneratesheets').val(0);
                }
              });
                //part1
                if (data[0].dashboard == 1){
                  $( "#moddashboard" ).prop( "checked", true );
                  $('#moddashboard').val(1);
                }else{
                  $( "#moddashboard" ).prop( "checked", false );
                  $('#moddashboard').val(0);
                }
             //part2
                $('#moddashboard').click(function() {
                if ($('#moddashboard').is(':checked')){
                    $('#moddashboard').val(1);
                } else{
                    $('#moddashboard').val(0);
                }
              });
              /**************/

          

          });









        });
              $('#editform').on('submit',function(e){
                  e.preventDefault();
                  var mydata={
                  id:$("#id").val(),
                  profil:$("#modprofil").val(),
                  showclient:$('#modshowclient').val(),
                  addclient:$('#modaddclient').val(),
                  updateclient:$('#modupdateclient').val(),
                  deleteclient:$('#moddeleteclient').val(),
                  showcommand:$('#modshowcommand').val(),
                  addcommand: $('#modaddcommand').val(),
                  updatecommandbef:$('#modupdatecommandbef').val(),
                  updatecommandaf:$('#modupdatecommandaf').val(),
                  deletecommand: $('#moddeletecommand').val(),
                  assigncommand:$('#modassigncommand').val(),
                  confirmcommand:$('#modconfirmcommand').val(),
                  cancelcommand: $('#modcancelcommand').val(),
                  manageprofils:$('#modmanageprofils').val(),
                  manageusers:$('#modmanageusers').val(),
                  managemotifs:$('#modmanagemotifs').val(),
                  manageagences: $('#modmanageagences').val(),
                  managesectors:$('#modmanagesectors').val(),
                  managecommercials: $('#modmanagecommercials').val(),
                  usershistory:$('#modusershistory').val(),
                  clientshistory:$('#modclientshistory').val(),
                  commandshistory: $('#modcommandshistory').val(),
                  generatesheets:$('#modgeneratesheets').val(),
                  dashboard:$('#moddashboard').val(),

              }
                 //alert($('#modprofil').val());
                 $.ajax({
                     type:"PUT",
                     url:"{{route('updateprofil')}}",
                     data:mydata,
                     headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    // data:$(this).serialize(),
                    success:function(data,response){
                    //console.log(response);
                    $('#editProfil').modal('hide');
                    $("#modprofil").val("");
                   // $('input.form-check-input').is(':unchecked');
                   $('.form-check-input').prop('checked', false);
                    $('#tabprofils').html('');
                    //alert(data.id);
                    for (var i = 0; i < data.length; i++) {
                    var line='<tr class="'+data[i].id+'"><td>'+data[i].id+'</td><td>'+data[i].profil+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                    $('#tabprofils').append(line);
                }
                   $('#success_modal').modal('show');

                   setTimeout(function() {
                       $('#success_modal').modal('hide');
                   }, 1000);
                 
                },
                     error:function(error){
                        $("#modmotif_error").text("");
                          var response=$.parseJSON(error.responseText);
                          //alert(response.errors);
                         $.each(response.errors,function(key,val){
                             $("#"+key+"_error").text(val[0]);
                         });
                       //  alert("echec de modification");
                     }
                 }); 
              });
             

            });
            </script>

            <!--delprofil ajax code-->       
     <script>
           $(document).ready(function(){
            $(document).on("click", "a.delbtn" , function() {
            $('#deleteProfil').modal('show');

            $tr=$(this).closest('tr');
            var data=$tr.children("td").map(function(){
                return $(this).text();
            }).get();

            $('#iddelprofil').val(data[0]);
        /*    $(document).on("click","#delete",function(e){
                e.preventDefault();
                var id=$('#iddeluser').val();
                //alert(id);

                   $.ajax({
                     type:"delete",
                     url:"/delete",
                     data:id,
                    // data:$(this).serialize(),
                     success:function(response){
                        $('#deleteUser').modal('hide'); 
                        alert("Utilisateur a été modifié avec succes");
                        location.reload();
                     },
                     error:function(error){
                         alert("echec de modification");
                     }
                 });

            });*/
              });

              $('#deleteFormID').on('submit',function(e){
               e.preventDefault();
               var id=$('#iddelmotif').val();

               $.ajax({
                     type:"delete",
                     url:"{{route('deleteProfil')}}",
                     data:$(this).serialize(),
                     success:function(data,response){
                        $('#deleteProfil').modal('hide'); 
                        //alert("Utilisateur a été modifié avec succes");
                        //location.reload();
                        //$("#tabusers").children().remove();
                        $("."+data.id).remove();


                        $('#success_modal').modal('show');
                         setTimeout(function() {
                             $('#success_modal').modal('hide');
                         }, 1000);
                     },
                     error:function(error){
                       alert(error);
                     }
                 });

              })

            });
            </script>

               <!-- Second Search bar-->
           <script>
            $(document).ready(function(){
            $("#secsearchbar").on("keyup", function() {
              var value = $(this).val().toLowerCase();
            $("#tabmotifs tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
             });
             });
             });
             </script>

             {{-- modifier les informations de l'utilisateur --}}
    <script>
        $(document).ready(function(){
            $('#editform2').on('submit',function(e){
                  e.preventDefault();
                  var totalFormData=new FormData($('#editform2')[0]);
                  totalFormData.append('_method', 'put');
                 // alert(totalFormData.modpassword);

                 $.ajax({
                     type:"POST",
                     url:"{{ route('updateuser2') }}",
                     processData: false,
                     contentType: false,
                     data:totalFormData,
                    // data:$(this).serialize(),
                     success:function(data,response){
                         $('#modpassword2').val('');
                         $('#modimage2').val('');
                        $('#changesettingsModal').modal('hide'); 

                        $('#success_modal').modal('show');

                         setTimeout(function() {
                             $('#success_modal').modal('hide');
                         }, 1000);
                         location.reload();
                         //window.location = "{{route('globstats3view')}}";
                     },
                     error:function(error){
                      alert("Erreur");
                     }
                 });
              });
        });
        </script>

</body>

</html>

@endsection