<!--style of progress bar-->
 <style type="text/css">
h2{
    color: #2F8D46;
}
#form {
    text-align: center;
    position: relative;
    margin-top: 20px
}
  
#form fieldset {
    background: white;
    border: 0 none;
    border-radius: 0.5rem;
    box-sizing: border-box;
    width: 100%;
    margin: 0;
    padding-bottom: 20px;
    position: relative
} 
  
.finish {
    text-align: center
}
  
#form fieldset:not(:first-of-type) {
    display: none
}

 /* 
#form .previous-step, .next-step {
    width: 100px;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 0px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px 10px 0px;
    float: right 
} */
  
.form, .previous-step {
    background: #616161;
}
  

.form, .next-step {
    background: #2F8D46;
}
  
  
.text {
    color: #2F8D46;
    font-weight: normal
}
  
#progressbar {
    margin-bottom: 30px;
    overflow: hidden;
    color: lightgrey
}
  
#progressbar .active {
    color: #2F8D46
}
  
#progressbar li {
    list-style-type: none;
    font-size: 15px;
    width: 25%;
    float: left;
    position: relative;
    font-weight: 400
}
  
#progressbar #step1:before {
    content: "1"
}
  
#progressbar #step2:before {
    content: "2"
}
  
#progressbar #step3:before {
    content: "3"
}
  
  
#progressbar li:before {
    width: 50px;
    height: 50px;
    line-height: 45px;
    display: block;
    font-size: 20px;
    color: #ffffff;
    background: lightgray;
    border-radius: 50%;
    margin: 0 auto 10px auto;
    padding: 2px
}
  
#progressbar li:after {
    content: '';
    width: 100%;
    height: 2px;
    background: lightgray;
    position: absolute;
    left: 0;
    top: 25px;
    z-index: -1
}
  
#progressbar li.active:before,
#progressbar li.active:after {
    background: #2F8D46
}
  
.progress {
    height: 20px
}
  
.progress-bar {
    background-color: #2F8D46!important;
}
 </style>
@extends('masterpage')

@section('content')

               <button id="show_chart" class="btn btn-primary"><i class="fas fa-chart-pie"></i> Afficher le diagramme circulaire</button>

              <!--multi step progress bar begin-->

              <div class="container">
                <div class="row justify-content-center">
                    <div class="col-11 col-sm-9 col-md-7 
                        col-lg-6 col-xl-5 text-center p-0 mt-3 mb-2">
                        <div class="px-0 pt-4 pb-0 mt-3 mb-3">
                            <div id="form">
                                <ul id="progressbar" style="margin-left:35px">
                                    <li class="active" id="step1">
                                        <strong>Etape 1</strong>
                                    </li>
                                    <li id="step2" class="active" ><strong>Etape 2</strong></li>
                                    <li id="step3" class="active"><strong>Etape 3</strong></li>
                               <!--     <li id="step4" class="fn"><strong>Etape 4</strong></li>  -->
                                </ul>
                                <div class="progress">
                                    <div class="progress-bar" style="width:100%;"></div>
                                </div> <br>
                            <!--    <fieldset>
                                    <h2>Votre fichier est prêt à exporter</h2>
                                </fieldset>
                                


                                <form action="{{route('importFram')}}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <h4>Vous pouvez générer une nouvelle feuille de ramassage</h4>
                                    <label for="">Importer une feuille de ramassage</label>
                                    <input type="file" name="file">
                                    <button type="submit" class="btn btn-success" >Valider</button>
                                    </form> -->
                                    

                                    <fieldset>
                                        <h2>Votre fichier est prêt pour l'exportation</h2>
                                    </fieldset>
                                   
                                
                            </div><!--end div id=form-->
                        </div>
                    </div>
                </div>
            </div>




              <!--multi step progress bar end-->








                <!--my table begin-->

                  <!--
                <form action="" enctype="multipart/form-data">
                @csrf
                <input type="file" name="file">
                <button type="submit" id="import_real_age_file"  class="btn btn-primary" >submit</button>
                </form>

                <form action="{{route('importExcel2')}}" method="post" enctype="multipart/form-data">
                    @csrf
                    <input type="file" name="file2">
                    <button type="submit" class="btn btn-primary">submit2</button>
                    </form> -->




                <div class="row">
            <div class="col-md-12">
                <div class="form-content">    

           <h3 class="text-center">Liste des clients</h3>

           <!--searchbar-->
           <div class="container input-group rounded" style="margin-bottom:7px;padding-left:80px;padding-right:80px">
             <input type="search" id="secsearchbar" class="form-control rounded" placeholder="Que cherchez-vous ? " aria-label="Search" aria-describedby="search-addon"/>
             <button class="btn btn-primary" style="border-top-right-radius:20px;border-bottom-right-radius:20px;border-top-left-radius:0px;border-bottom-left-radius:0px"  disabled>
               <i class="fas fa-search"></i>
             </button>
           </div>

           
           <div class="row justify-content-between">
                 <div class="col-md-3">
                   <a id="exportfile" href="#" class="btn btn-success" style="margin-bottom:5px"><img src="{{asset('customAuth/images/excel.ico')}}" alt="" style="width:35px;height:35px">Exporter</a>
                </div>

                <div class="col-md-6">
               <center> <h3><b><span id="Fpass_clients"></span></b> clients trouvés</h3></center>
                </div>


                <div class="ml-auto mr-3">
                    <a href="#" class="btn btn-primary" id="delete_table_btn" ><i class="fas fa-refresh fa-spin" aria-hidden="true" style="margin-right:5px" ></i>Recommencer à nouveau</a>
                </div>
          </div>

           <table id="statisticsTab" class="table table-striped table-bordered" style="width:100%">
           <thead class="thead thead-dark">
             <tr>
             <th >Client</th>
             <th >Secteur</th>
             <th>S1</th>
             <th>S2</th>
             <th>S3</th>
             <th>S4</th>
             <th>S5</th>
             <th>Total Passage</th>
             <th>0</th>
             <th>1*2</th>
             <th>3*5</th>
             </tr>
             </thead>
             <tbody id="tabstatistics">
          
             </tbody>
           </table>
                </div>
        </div>
        </div>
        <!--end of my table-->

              <!-- Footer -->
              <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Ramex 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->


        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
         
          <div class="modal-body">
              <div class="row">
                  <div class="col-md-4"> <img src="{{ asset('customAuth/images/logout.jpg') }}" alt="" style="width:130px;height:130px"></div>
                  <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h5>voulez-vous vraiment vous déconnecter ?</h5></center></div>
              </div>

              
               <center>  
                  <a class="btn btn-primary " href="{{ route('logout') }}"
                                     onclick="event.preventDefault();
                                                   document.getElementById('logout-form').submit();">
                                      {{ __('Se Déconnecter') }}</a>
                                      <button class="btn btn-secondary " type="button" data-dismiss="modal">Quitter</button>
                                  </center>
                                      <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                      @csrf
                                  </form>
                              
          </div>
          
      </div>
  </div>
</div>


     
     <!--delete html table modal-->
     <div class="modal fade" id="deleteStatistics" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content" style="background-color:#0fa7ff;border-radius:20px;color:white;height:267px"> 
 
             <form id="deleteFormID">
              <div class="modal-body"> 
              {{csrf_field()}}
              {{method_field('delete')}}
              <div class="row">
                 <div class="col-md-4"> <img src="{{ asset('customAuth/images/warning.gif') }}" alt="" style="width:150px;height:150px"></div>
                 <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Voulez vous vraiment recommencer à nouveau ?</h3></center></div>
             </div>
         <!--     <i class="fas fa-exclamation-triangle" style="font-size:30px; color:#ffcc00"></i> Voulez vous vraiment supprimer cet utilisateur? -->
         <center>
             <button type="submit" id="delete" class="btn btn-danger btn-lg" >Recommencer</button>
             <button class="btn btn-secondary btn-lg" type="button" data-dismiss="modal">Quitter</button>
             </center>   
     </div>
            
             
             </form>
             
         </div>
     </div>
 </div>





    
       <!--success modal begin-->
        <!-- Modal -->
        <div class="modal fade" id="success_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document" >
              <div class="modal-content" style="background-color:rgb(35, 220, 61);border-radius:40px;color:white">
                <div class="modal-body" >
               
                  <div class="row">
                      <div class="col-md-4"> <img src="{{ asset('customAuth/images/check.gif') }}" alt=""></div>
                      <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Cette opération est terminée avec succès</h3></center></div>
                  </div>
                
                </div>
    
              </div>
            </div>
          </div>
      <!--susccess modal end-->
      

      <!--export excel file Modal -->
<div class="modal fade" id="exportexcelfile_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:rgb(75, 181, 67);color:white">
          <h3 ><i class="fas fa-file-excel-o"></i> Exporter le fichier</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="{{route('exportExcelPassage')}}" method="get" enctype="multipart/form-data">
                @csrf

                <div class="input-group" style="margin-bottom:5px">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="">Noms des colonnes</span>
                    </div>
                    <input type="text" class="form-control"  name="nom_colonne_1">
                    <input type="text" class="form-control"  name="nom_colonne_2">
                    <input type="text" class="form-control"  name="nom_colonne_3">
                    <input type="text" class="form-control"  name="nom_colonne_4">
                    <input type="text" class="form-control"  name="nom_colonne_5">
                  </div>

                  <label for="" style="font-size: 20px">Nom du fichier :</label>
                  <input type="text" class="form-control form-control-lg" name="nom_fichier_excel" value="PASSAGE" placeholder="Exemple: PASSAGE 18">

                <div style="margin-top:10px">
                    <center>
                        <button id="close_export_file_modal" type="submit" class="btn btn-success" style="margin-right:3px"><i class="fas fa-download"></i> Exporter</a>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>  
                    </center>  
                </div>  
                </form>
        </div>
      </div>
    </div>
  </div>
  <!--end export excel file Modal -->



       <!--chart-bar Modal -->
<div class="modal fade bd-example-modal-lg" id="chartbar_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:rgb(2, 117, 216);color:white">
          <h3 ><i class="fas fa-chart-pie"></i> Pourcentage des clients dans chaque catégorie</h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color:white">&times;</span>
          </button>
        </div>
        <div class="modal-body">
<!--chart body begin-->
<div class="row">

    <!-- Area Chart -->
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Body -->
            <div class="card-body">
            
                <!--my chart-->             
                <div id="chart" class="chart-area">
                    
                </div>
            </div>
        </div>
    </div>

   
</div>
<!--chart body end-->
<!--
            <div style="margin-top:10px">
                    <center>
                        <button id="download_as_pdf" type="submit" class="btn btn-success" style="margin-right:3px"><i class="fas fa-download"></i> Exporter</a>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>  
                    </center>  
                </div>  -->
        </div>
      </div>
    </div>
  </div>
  <!--end Chart-bar Modal -->




    <!--edit user modal begin-->
<!-- Modal -->
<div class="modal fade" id="changesettingsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#4e73df; color:white">
          <h5 class="modal-title" id="exampleModalLabel">Modifier votre paramètres</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color:white">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!--begin of my form-->
          <div class="col-lg-12">
      
                      <form id="editform2" enctype="multipart/form-data">
                       @csrf
                       {{method_field('PUT')}}
                       
                          <div class="form-group">
                                  <label for="">Changer votre image de profil</label>
                                  <input id="modimage2" type="file" class="form-control"
                                   name="modimage2">
                          </div>
  
                         
  
                          <div class="form-group">
                            <label for="">Changer votre mot de passe</label>
                                   <input id="modpassword2" type="password" class="form-control form-control-user @error('password') is-invalid @enderror"
                                    name="modpassword2" placeholder="Nouveau mot de passe" autocomplete="Nouveau mot de passe">
                                    <small id="modpassword_error" class="form-text text-danger"></small>
                          </div>
  
                        <center>
                          <button type="submit" class="btn btn-primary">Enregistrer </button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                        </center>
                      </form>
                  
              </div>
          <!--end of my form-->
        </div>
      </div>
    </div>
  </div>
      <!--edit user modal end-->

  


    <!-- Bootstrap core JavaScript-->
    <script src="{{asset('customAuth/vendor/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('customAuth/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>

    <!-- Core plugin JavaScript-->
    <script src="{{asset('customAuth/vendor/jquery-easing/jquery.easing.min.js')}}"></script>

    <!-- Custom scripts for all pages-->
    <script src="{{asset('customAuth/js/sb-admin-2.min.js')}}"></script>


       <!--chart scripts-->
     <!-- Charting library -->
     <script src="{{asset('js/echarts.min.js')}}"></script>
     <!-- Chartisan -->
     <script src="{{asset('js/chartisan_echarts.js')}}"></script>
     <!-- Your application script -->

     <!-- Charting library -->
<script src="{{asset('js/Chart.min.js')}}"></script>
<!-- Chartisan -->
<script src="{{asset('js/chartisan_chartjs.umd.js')}}"></script>


<!--import the script for download pdf-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js" integrity="sha512-s/XK4vYVXTGeUSv4bRPOuxSDmDlTedEpMEcAQk0t/FMd9V6ft8iXdwSBxV0eD60c6w/tjotSlKu9J2AAW1ckTA==" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.js" integrity="sha512-jzL0FvPiDtXef2o2XZJWgaEpVAihqquZT/tT89qCVaxVuHwJ/1DFcJ+8TBMXplSJXE8gLbVAUv+Lj20qHpGx+A==" crossorigin="anonymous"></script>
<!--the script-->
<script>
$('#download_as_pdf').click(function () {
window.jsPDF = window.jspdf.jsPDF;
html2canvas($("#chart"),{
            onrendered: function(canvas) {  
            
                var imgData = canvas.toDataURL("image/png");              
                var doc = new jsPDF();
                
                doc.addImage(imgData, 'PNG', 0, 30,200,60);
                doc.internal.scaleFactor = 5;
                doc.save('sample-file.pdf');
            }
        });
    });
</script>
    

<!--show content table-->
<script>
    $(document).ready(function() {
        $.get("{{ route('AllStatistics4') }}", function(data, response){
                
                for (var i = 0; i < data.length; i++) {
                   
                        var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].client+'</td><td>'+data[i].secteur+'</td><td>'+data[i].s1+'</td><td>'+data[i].s2+'</td><td>'+data[i].s3+'</td><td>'+data[i].s4+'</td><td>'+data[i].s5+'</td><td>'+data[i].total_passage+'</td><td>'+data[i].cat_0+'</td><td>'+data[i].cat_12+'</td><td>'+data[i].cat_35+'</td><tr/>';
                       
                    $('#tabstatistics').append(line);
                }

                //////// compter le nombres des clients dans la feuilles passage
                $.get("{{ route('AllPassageClients') }}", function(data, response){
                
                $("#Fpass_clients").text(data);
               
             });
                //////// end counter

                ///// chart part begin
                const chart = new Chartisan({
            el: '#chart',
            url: "@chart('passage_chart')",
            hooks: new ChartisanHooks()
            .datasets('doughnut')
            .pieColors()
            .responsive()
             });
                ///// end chart part


              
            });

/*
            const chart = new Chartisan({
            el: '#chart',
            url: "@chart('passage_chart')",
            hooks: new ChartisanHooks()
            .datasets('doughnut')
            .pieColors()
            .responsive()
             });*/

    });
    </script>


   <!--select count clients -->
   <script>
    $(document).ready(function() {
        $.get("{{ route('AllPassageClients') }}", function(data, response){
                
               $("#Fpass_clients").text(data);
              
            });
    });
    </script>



<!--importer le fichier de l'age reel-->
<script>
/*
$(document).ready(function() {
    $('#import_real_age_file').on('click',function(e){
        
        e.preventDefault();
    
        var totalFormData=new FormData($('#add_real_age_file')[0]);
       // alert(totalFormData.file);

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:"/importExcel",
                processData: false,
                contentType: false,
                data:totalFormData,
               // data:$('#add_real_age_file').serialize(),
                success:function(data,response){
                   alert("success");

                },
                error:function(error){
                  alert("error");
                }
              }); 
      })
    });
*/
</script>

<!--export button-->
<script>
			
    $(document).ready(function() {
        $("#export_btn").click(function () {

           alert("test");

        });
    });
</script>

<!--Search bar-->
<script>
    $(document).ready(function(){
       $("#searchbar").on("keyup", function() {
         var value = $(this).val().toLowerCase();
      $("#tabstatistics tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
       });
       });
      });
</script>



<!--secSearch bar-->
<script>
    $(document).ready(function(){
       $("#secsearchbar").on("keyup", function() {
         var value = $(this).val().toLowerCase();
      $("#tabstatistics tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
       });
       });
      });
</script>

<!--vider la table-->
<script>
    $(document).ready(function(){
        $('#delete_table_btn').click(function(e){
        
        e.preventDefault();
        $("#deleteStatistics").modal("show");
/*
        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"{{route('deleteAllTable')}}",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   alert("success");

                },
                error:function(error){
                  alert("error");
                }
              });  */
      })

      $('#delete').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"{{route('deleteAllTable')}}",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
         /*        $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */

                 window.location = "{{route('passageview')}}";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })


//delete2 
$('#zero_ram').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"{{route('deleteAllTable')}}",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "{{route('zeroramview')}}";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })


      $('#tac_ram').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"{{route('deleteAllTable')}}",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "{{route('tacramview')}}";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })



      $('#f_passage').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"{{route('deleteAllTable')}}",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "{{route('passageview')}}";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })


      $('#f_globale').click(function(e){
        
        e.preventDefault();
       
        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"{{route('deleteAllTable')}}",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "{{route('globstatsview')}}";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })

      });
</script>

     <!--ajouter les nom des fichier dans la balise ul-->
<script>
    $(document).ready(function(){

/*        
    if ($('#filenames li').length != 0){
        $("#filenamescontent").addClass('filenamescontentstyle');
        $("#filenamescontent").addClass('overflow-auto');
    }  */
    
        $.get("{{ route('importedfiles') }}", function(data, response){
                    //alert(data[0].nom_fichier);
                    for (var i = 0; i < data.length; i++) {
                        if(data[i].type_fichier == "age_0ram"){
                            var line=' <li class="list-group-item list-group-item-success">'+data[i].nom_fichier+'</li>';
                        $('#filenames').append(line);
                        }       
                    }
                  
                });
    
          });
    </script>      


<!--Afficher le modal exportexcel-->
<script>
    $(document).ready(function(){
      $("#exportfile").click(function(){
        $("#exportexcelfile_modal").modal("show");
      })
      });
</script>




<!--Afficher le modal du diagramme-->
<script>
    $(document).ready(function(){
      $("#show_chart").click(function(){
        $("#chartbar_modal").modal("show");
      })

      $("#close_export_file_modal").click(function(){
        $(".modal").modal("hide");
      })
      });
</script>

{{-- modifier les informations de l'utilisateur --}}
<script>
    $(document).ready(function(){
        $('#editform2').on('submit',function(e){
              e.preventDefault();
              var totalFormData=new FormData($('#editform2')[0]);
              totalFormData.append('_method', 'put');
             // alert(totalFormData.modpassword);

             $.ajax({
                 type:"POST",
                 url:"{{ route('updateuser2') }}",
                 processData: false,
                 contentType: false,
                 data:totalFormData,
                // data:$(this).serialize(),
                 success:function(data,response){
                     $('#modpassword2').val('');
                     $('#modimage2').val('');
                    $('#changesettingsModal').modal('hide'); 

                    $('#success_modal').modal('show');

                     setTimeout(function() {
                         $('#success_modal').modal('hide');
                     }, 2000);
                     location.reload();
                     //window.location = "{{route('globstats3view')}}";
                 },
                 error:function(error){
                  alert("Erreur");
                 }
             });
          });
    });
    </script>


</body>

</html>

@endsection