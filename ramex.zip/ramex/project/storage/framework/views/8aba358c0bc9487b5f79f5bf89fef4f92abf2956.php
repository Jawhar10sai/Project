

<?php $__env->startSection('content'); ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h1 class="h3 mb-0 text-gray-800">Tableau de bord</h1>
</div>

<!-- Content Row -->
<div class="row">


      <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-md font-weight-bold text-primary text-uppercase mb-1">
                        Demandes de ramassage d'aujourd'hui </div>
                  <center><div id="dem" class="h3 mb-0 font-weight-bold text-gray-800"></div></center>
                </div>
                <div class="col-auto">
                    <i class="fas fa-box fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>
</div>


    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div id="nv_dem_title" class="text-md font-weight-bold text-uppercase mb-1">
                            Demandes en attente d'affectation</div>
                       <center><div id="nv_dem" class="h3 mb-0 font-weight-bold text-gray-800"></div></center>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-tasks fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div id="af_dem_title" class="text-md font-weight-bold text-uppercase mb-1">
                            Demandes en attente de confirmation</div>
                        <center><div id="af_dem" class="h3 mb-0 font-weight-bold text-gray-800"></div></center>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-check fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

  <!-- Earnings (Monthly) Card Example -->
  <div class="col-xl-3 col-md-6 mb-4">
    <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
            <div class="row no-gutters align-items-center">
                <div class="col mr-2">
                    <div class="text-md font-weight-bold text-danger text-uppercase mb-1">
                        Demandes annulées </div><br>
                    <center><div id="an_dem" class="h3 mb-0 font-weight-bold text-gray-800"></div></center>
                </div>
                <div class="col-auto">
                    <i class="fas fa-close fa-2x text-gray-300"></i>
                </div>
            </div>
        </div>
    </div>
</div>

    

</div> <!-- Content Row -->

<div class="row">
    <!-- Area Chart -->
    <div class="col-lg-12">
        <div class="card shadow mb-4">
            <!-- Card Header - Dropdown -->
            <div
                class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">L'évolution de notre activité au cours des trois derniers mois</h6>
                
            </div>
            <!-- Card Body -->
            <div class="card-body">
            
                <!--my chart-->             
                <div id="chart" class="chart-area">
                    
                </div>
            </div>
        </div>
    </div>  
</div>

 <!-- Footer -->
 <footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Ramex 2021</span>
        </div>
    </div>
</footer>
<!-- End of Footer -->


</div>
<!-- /.container-fluid -->


    </div>
    <!-- End of Main Content -->

 

</div>
<!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
<i class="fas fa-angle-up"></i>
</a>


<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
aria-hidden="true">
<div class="modal-dialog" role="document">
 <div class="modal-content">
    
     <div class="modal-body">
         <div class="row">
             <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/logout.jpg')); ?>" alt="" style="width:130px;height:130px"></div>
             <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h5>voulez-vous vraiment vous déconnecter ?</h5></center></div>
         </div>

         
          <center>  
             <a class="btn btn-primary " href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                              document.getElementById('logout-form').submit();">
                                 <?php echo e(__('Se Déconnecter')); ?></a>
                                 <button class="btn btn-secondary " type="button" data-dismiss="modal">Quitter</button>
                             </center>
                                 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                 <?php echo csrf_field(); ?>
                             </form>
                         
     </div>
     
 </div>
</div>
</div>

<!--edit user modal begin-->
<!-- Modal -->
<div class="modal fade" id="changesettingsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
<div class="modal-header" style="background-color:#4e73df; color:white">
  <h5 class="modal-title" id="exampleModalLabel">Modifier votre paramètres</h5>
  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
    <span aria-hidden="true" style="color:white">&times;</span>
  </button>
</div>
<div class="modal-body">
  <!--begin of my form-->
  <div class="col-lg-12">

              <form id="editform2" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <?php echo e(method_field('PUT')); ?>

               
                  <div class="form-group">
                          <label for="">Changer votre image de profil</label>
                          <input id="modimage2" type="file" class="form-control"
                           name="modimage2">
                  </div>

                 

                  <div class="form-group">
                    <label for="">Changer votre mot de passe</label>
                           <input id="modpassword2" type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="modpassword2" placeholder="Nouveau mot de passe" autocomplete="Nouveau mot de passe">
                            <small id="modpassword_error" class="form-text text-danger"></small>
                  </div>

                <center>
                  <button type="submit" class="btn btn-primary">Enregistrer </button>
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                </center>
              </form>
          
      </div>
  <!--end of my form-->
</div>
</div>
</div>
</div>
<!--edit user modal end-->


<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('customAuth/vendor/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('customAuth/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('customAuth/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('customAuth/js/sb-admin-2.min.js')); ?>"></script>





<!--chart scripts-->
<!-- Charting library -->
<script src="<?php echo e(asset('js/echarts.min.js')); ?>"></script>
<!-- Chartisan -->
<script src="<?php echo e(asset('js/chartisan_echarts.js')); ?>"></script>
<!-- Your application script -->

<!-- Charting library -->
<script src="<?php echo e(asset('js/Chart.min.js')); ?>"></script>
<!-- Chartisan -->
<script src="<?php echo e(asset('js/chartisan_chartjs.umd.js')); ?>"></script>
<script>
 
const chart = new Chartisan({
el: '#chart',
url: "<?php echo route('charts.'.'ramassage_chart'); ?>",
hooks: new ChartisanHooks()
.beginAtZero()
.responsive()
.colors(),
});
</script>
<!--chart scripts end-->


<!--dashboard-->
<script>
$(document).ready(function(){
$.ajax({
    url: "<?php echo e(route('dashboard')); ?>",
    success: 
      function(data){
        $("#dem").text(data[0]);
        $("#nv_dem").text(data[1]);
        $("#af_dem").text(data[2]);
        $("#an_dem").text(data[3]);
        if(data[1] != 0){
           $("#nv_dem_title").addClass("nouvelle-demande");
         // alert("test");
         //  $("#nv_dem").addClass("nouvelle-demande");
        } else{
            $("#nv_dem_title").addClass("text-info");    
        }

        if(data[2] != 0){
           $("#af_dem_title").addClass("nouvelle-demande");
         // alert("test");
         //  $("#nv_dem").addClass("nouvelle-demande");
        } else{
            $("#af_dem_title").addClass("text-warning");    
        }
       // setInterval(sendRequest, 10000);
    },
    complete: function() {
   // Schedule the next request when the current one's complete
 //  setInterval(sendRequest, 10000); // The interval set to 5 seconds
 }
});
setInterval(sendRequest,10000);
function sendRequest(){
  $.ajax({
    url: "<?php echo e(route('dashboard')); ?>",
    success: 
      function(data){
        $("#dem").text(data[0]);
        $("#nv_dem").text(data[1]);
        $("#af_dem").text(data[2]);
        $("#an_dem").text(data[3]);
        if(data[1] != 0){
           $("#nv_dem_title").addClass("nouvelle-demande");
         // alert("test");
         //  $("#nv_dem").addClass("nouvelle-demande");
        } else{
            $("#nv_dem_title").addClass("text-info");    
        }

        if(data[2] != 0){
           $("#af_dem_title").addClass("nouvelle-demande");
         // alert("test");
         //  $("#nv_dem").addClass("nouvelle-demande");
        } else{
            $("#af_dem_title").addClass("text-warning");    
        }
       // setInterval(sendRequest, 10000);
    },
    complete: function() {
   // Schedule the next request when the current one's complete
 //  setInterval(sendRequest, 10000); // The interval set to 5 seconds
 }
});
};
        });
</script>


<script>
$(document).ready(function(){
$('#editform2').on('submit',function(e){
      e.preventDefault();
      var totalFormData=new FormData($('#editform2')[0]);
      totalFormData.append('_method', 'put');
     // alert(totalFormData.modpassword);

     $.ajax({
         type:"POST",
         url:"<?php echo e(route('updateuser2')); ?>",
         processData: false,
         contentType: false,
         data:totalFormData,
        // data:$(this).serialize(),
         success:function(data,response){
             $('#modpassword2').val('');
             $('#modimage2').val('');
            $('#changesettingsModal').modal('hide'); 

            $('#success_modal').modal('show');

             setTimeout(function() {
                 $('#success_modal').modal('hide');
             }, 2000);
             location.reload();
             //window.location = "<?php echo e(route('globstats3view')); ?>";
         },
         error:function(error){
          alert("Erreur");
         }
     });
  });
});
</script>


</body>

</html>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ramex\project\resources\views/homeadmin.blade.php ENDPATH**/ ?>