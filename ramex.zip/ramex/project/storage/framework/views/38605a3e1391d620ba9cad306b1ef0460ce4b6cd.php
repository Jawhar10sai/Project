

<!--style of progress bar-->
 <style type="text/css">
h2{
    color: #2F8D46;
}
#form {
    text-align: center;
    position: relative;
    margin-top: 20px
}
  
#form fieldset {
    background: white;
    border: 0 none;
    border-radius: 0.5rem;
    box-sizing: border-box;
    width: 100%;
    margin: 0;
    padding-bottom: 20px;
    position: relative
} 
  
.finish {
    text-align: center
}
  
#form fieldset:not(:first-of-type) {
    display: none
}

 /* 
#form .previous-step, .next-step {
    width: 100px;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 0px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px 10px 0px;
    float: right 
} */
  
.form, .previous-step {
    background: #616161;
}
  

.form, .next-step {
    background: #2F8D46;
}
  
  
.text {
    color: #2F8D46;
    font-weight: normal
}
  
#progressbar {
    margin-bottom: 30px;
    overflow: hidden;
    color: lightgrey
}
  
#progressbar .active {
    color: #2F8D46
}
  
#progressbar li {
    list-style-type: none;
    font-size: 15px;
    width: 25%;
    float: left;
    position: relative;
    font-weight: 400
}
  
#progressbar #step1:before {
    content: "1"
}
  
#progressbar #step2:before {
    content: "2"
}
  
#progressbar #step3:before {
    content: "3"
}
  
  
#progressbar li:before {
    width: 50px;
    height: 50px;
    line-height: 45px;
    display: block;
    font-size: 20px;
    color: #ffffff;
    background: lightgray;
    border-radius: 50%;
    margin: 0 auto 10px auto;
    padding: 2px
}
  
#progressbar li:after {
    content: '';
    width: 100%;
    height: 2px;
    background: lightgray;
    position: absolute;
    left: 0;
    top: 25px;
    z-index: -1
}
  
#progressbar li.active:before,
#progressbar li.active:after {
    background: #2F8D46
}
  
.progress {
    height: 20px
}
  
.progress-bar {
    background-color: #2F8D46!important;
}
 </style>




<?php $__env->startSection('content'); ?>

              <!--multi step progress bar begin-->
              <div class="container">
                <div class="row justify-content-center">
                    <div class="col-11 col-sm-9 col-md-7 
                        col-lg-6 col-xl-5 text-center p-0 mt-3 mb-2">
                        <div class="px-0 pt-4 pb-0 mt-3 mb-3">
                            <div id="form">
                                <ul id="progressbar" style="margin-left:35px">
                                    <li class="active" id="step1">
                                        <strong>Etape 1</strong>
                                    </li>
                                    <li id="step2" class="active" ><strong>Etape 2</strong></li>
                                    <li id="step3" ><strong>Etape 3</strong></li>
                               <!--     <li id="step4" class="fn"><strong>Etape 4</strong></li>  -->
                                </ul>
                                <div class="progress">
                                    <div class="progress-bar" style="width:67%;"></div>
                                </div> <br>
                               
                                <fieldset>
                                    <h2>Importer le fichier global </h2>
                                </fieldset>
                               
                                <form action="<?php echo e(route('importExcel10')); ?>" method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <label for="">Incrementer l'age réel avec:</label>
                                    <input type="number" id="inc_age_reel" class="form-control" name="inc_age_reel" value="" style="margin-bottom: 3px" required>
                                    <input type="file" name="file" accept=".xls, .xlsx">
                                    <button type="submit" id="send_age" class="btn btn-success" >Valider</button>
                                    </form>
                            </div><!--end div id=form-->
                          
                        </div>
                    </div>
                </div>
            </div>




              <!--multi step progress bar end-->

                 <!--my table begin-->

                 <div class="row">
                    <div class="col-md-12">
                        <div class="form-content">    
        
                   <h3 class="text-center">Liste des clients</h3>
        
                   <!--searchbar-->
                   <div class="container input-group rounded" style="margin-bottom:7px;padding-left:80px;padding-right:80px">
                     <input type="search" id="secsearchbar" class="form-control rounded" placeholder="Que cherchez-vous ? " aria-label="Search" aria-describedby="search-addon"/>
                     <button class="btn btn-primary" style="border-top-right-radius:20px;border-bottom-right-radius:20px;border-top-left-radius:0px;border-bottom-left-radius:0px"  disabled>
                       <i class="fas fa-search"></i>
                     </button>
                   </div>

                   

                   
                   <div class="row justify-content-between">
                      <div class="col-md-3">
                        <a id="exportfile" href="#" class="btn btn-success" style="margin-bottom:5px"><img src="<?php echo e(asset('customAuth/images/excel.ico')); ?>" alt="" style="width:35px;height:35px">Exporter</a>
                    </div>


                      <div class="col-md-6">
                        <center> <h3><b><span id="All_fram_clients"></span></b> clients trouvés</h3></center>
                         </div>

                    
                      <div class="ml-auto mr-3" >
                        <a href="#" class="btn btn-primary" id="delete_table_btn" ><i class="fas fa-refresh fa-spin" aria-hidden="true" style="margin-right:5px" ></i>Recommencer à nouveau</a>
                    </div>
                   </div>


                
                   <table id="statisticsTab" class="table table-striped table-bordered">
                   <thead class="thead thead-dark">
                     <tr>
                     <th >Commercial</th>
                     <th >Client</th>
                     <th>Âge réel (En semaine)</th>
                     <th>Âge avec 0 ramassage (En semaine)</th>
                     <th>Âge avec 3*5 ramassage (En semaine)</th>
                     </tr>
                     </thead>
                     <tbody id="tabstatistics" >
                  
                     </tbody>
                   </table>
                

                   
                </div>
                </div>
                 </div>
        <!--end of my table-->
        
                  <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Ramex 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

           

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>


 <!-- Logout Modal-->
 <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
 aria-hidden="true">
 <div class="modal-dialog" role="document">
     <div class="modal-content">
        
         <div class="modal-body">
             <div class="row">
                 <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/logout.jpg')); ?>" alt="" style="width:130px;height:130px"></div>
                 <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h5>voulez-vous vraiment vous déconnecter ?</h5></center></div>
             </div>

             
              <center>  
                 <a class="btn btn-primary " href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                  document.getElementById('logout-form').submit();">
                                     <?php echo e(__('Se Déconnecter')); ?></a>
                                     <button class="btn btn-secondary " type="button" data-dismiss="modal">Quitter</button>
                                 </center>
                                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                     <?php echo csrf_field(); ?>
                                 </form>
                             
         </div>
         
     </div>
 </div>
</div>



   





     <!--success modal begin-->
        <!-- Modal -->
        <div class="modal fade" id="succes" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
          <div class="modal-dialog" role="document" >
            <div class="modal-content" style="background-color:rgb(35, 220, 61);border-radius:40px;color:white">
              <div class="modal-body" >
             
                <div class="row">
                    <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/check.gif')); ?>" alt=""></div>
                    <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Cette opération est terminée avec succès</h3></center></div>
                </div>
              
              </div>
  
            </div>
          </div>
        </div>
    <!--susccess modal end-->



     
     <!--delete html table modal-->
     <div class="modal fade" id="deleteStatistics" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
     <div class="modal-dialog" role="document">
         <div class="modal-content" style="background-color:#0fa7ff;border-radius:20px;color:white;height:267px"> 
 
             <form id="deleteFormID">
              <div class="modal-body"> 
              <?php echo e(csrf_field()); ?>

              <?php echo e(method_field('delete')); ?>

              <div class="row">
                 <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/warning.gif')); ?>" alt="" style="width:150px;height:150px"></div>
                 <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Voulez vous vraiment recommencer à nouveau ?</h3></center></div>
             </div>
         <!--     <i class="fas fa-exclamation-triangle" style="font-size:30px; color:#ffcc00"></i> Voulez vous vraiment supprimer cet utilisateur? -->
         <center>
             <button type="submit" id="delete" class="btn btn-danger btn-lg" >Recommencer</button>
             <button class="btn btn-secondary btn-lg" type="button" data-dismiss="modal">Quitter</button>
             </center>   
     </div>
            
             
             </form>
             
         </div>
     </div>
 </div>



 <!--delete html table modal end -->


 
       <!--success modal begin-->
        <!-- Modal -->
        <div class="modal fade" id="success_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document" >
              <div class="modal-content" style="background-color:rgb(35, 220, 61);border-radius:40px;color:white">
                <div class="modal-body" >
               
                  <div class="row">
                      <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/check.gif')); ?>" alt=""></div>
                      <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Cette opération est terminée avec succès</h3></center></div>
                  </div>
                
                </div>
    
              </div>
            </div>
          </div>
      <!--susccess modal end-->


       <!--export excel file Modal -->
       <div class="modal fade" id="exportexcelfile_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header" style="background-color:rgb(75, 181, 67);color:white">
              <h3 ><i class="fas fa-file-excel-o"></i> Choisir un nom au fichier</h3>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route('exportFglobal')); ?>" method="get" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control form-control-lg" name="nom_fichier_excel" value="FICHIER GLOBAL S" placeholder="Exemple: FICHIER GLOBAL S15">
                    <div style="margin-top:10px">
                        <center>
                            <button type="submit" class="btn btn-success" style="margin-right:3px"><i class="fas fa-download"></i> Exporter</a>
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>  
                        </center>  
                    </div>  
                    </form>
            </div>
          </div>
        </div>
      </div>
      <!--end export excel file Modal -->



         <!--update null age Modal -->
<div class="modal fade" id="updatenullage_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:rgb(75, 181, 67);color:white">
          <h3 >Client <b><span class="nom_client"></span></b></h3>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form action="" method="get" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
               <h5>Veuillez entrer l'age réel du client par semaine :</h5>
               <input type="text" id="id_client" hidden>
                <input type="number" id="age_reel_client" class="form-control form-control-lg" name="age_reel_client" placeholder="Exemple: 9">
                <div style="margin-top:10px">
                    <center>
                        <button id="update_age_client" type="submit" class="btn btn-success" style="margin-right:3px"><i class="fas fa-check"></i> Valider</a>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>  
                    </center>  
                </div>  
                </form>
        </div>
      </div>
    </div>
  </div>
  <!--end export excel file Modal -->
   


    <!--edit user modal begin-->
<!-- Modal -->
<div class="modal fade" id="changesettingsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#4e73df; color:white">
          <h5 class="modal-title" id="exampleModalLabel">Modifier votre paramètres</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color:white">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!--begin of my form-->
          <div class="col-lg-12">
      
                      <form id="editform2" enctype="multipart/form-data">
                       <?php echo csrf_field(); ?>
                       <?php echo e(method_field('PUT')); ?>

                       
                          <div class="form-group">
                                  <label for="">Changer votre image de profil</label>
                                  <input id="modimage2" type="file" class="form-control"
                                   name="modimage2">
                          </div>
  
                         
  
                          <div class="form-group">
                            <label for="">Changer votre mot de passe</label>
                                   <input id="modpassword2" type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="modpassword2" placeholder="Nouveau mot de passe" autocomplete="Nouveau mot de passe">
                                    <small id="modpassword_error" class="form-text text-danger"></small>
                          </div>
  
                        <center>
                          <button type="submit" class="btn btn-primary">Enregistrer </button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                        </center>
                      </form>
                  
              </div>
          <!--end of my form-->
        </div>
      </div>
    </div>
  </div>
      <!--edit user modal end-->




    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('customAuth/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customAuth/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('customAuth/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('customAuth/js/sb-admin-2.min.js')); ?>"></script>

    


<!--tooltip jquery-->
<script>
$(document).ready(function() {
    $("body").tooltip({ selector: '[data-toggle=tooltip]' });
});
</script>


<!--show zero ram modal-->
<script>
    $(document).ready(function() {
      $("#zero_ram_modal").click(function(){
          alert("uyqhs");
      })
    });
    </script>



<!--importer le fichier de l'age reel-->
<script>
/*
$(document).ready(function() {
    $('#import_real_age_file').on('click',function(e){
        
        e.preventDefault();
    
        var totalFormData=new FormData($('#add_real_age_file')[0]);
       // alert(totalFormData.file);

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:"/importExcel",
                processData: false,
                contentType: false,
                data:totalFormData,
               // data:$('#add_real_age_file').serialize(),
                success:function(data,response){
                   alert("success");

                },
                error:function(error){
                  alert("error");
                }
              }); 
      })
    });
*/
</script>


<!--show content table -->
<script>
    $(document).ready(function() {

        
        $.get("<?php echo e(route('AllStatistics1')); ?>", function(data, response){
                
                for (var i = 0; i < data.length; i++) {
                   var line='';
                 //  if(data[i].age_reel == null){
                      // line='<tr class="'+data[i].id+' clickabletr" style="background-color:rgb(231, 161, 176)"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].commercial+'</td><td>'+data[i].client+'</td><td>'+data[i].age_reel+'</td><td>'+data[i].age_avec_0ramassage+'</td><tr/>';
                   //}else{
                       line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].commercial+'</td><td>'+data[i].client+'</td><td>'+data[i].age_reel+'</td><td>'+data[i].age_avec_0ramassage+'</td><td>'+data[i].age_avec_3_5ramassage+'</td><tr/>';
                 //  }
                       
                    $('#tabstatistics').append(line);
                }
              
            });


            

            
    });
    </script>

    <!--select count clients-->
<script>
    $(document).ready(function() {
        $.get("<?php echo e(route('AllFramClients')); ?>", function(data, response){
                
               $("#All_fram_clients").text(data);
              
            });
    });
    </script>



<!--Search bar-->
<script>
    $(document).ready(function(){
       $("#searchbar").on("keyup", function() {
         var value = $(this).val().toLowerCase();
      $("#tabstatistics tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
       });
       });
      });
</script>



<!--secSearch bar-->
<script>
    $(document).ready(function(){
       $("#secsearchbar").on("keyup", function() {
         var value = $(this).val().toLowerCase();
      $("#tabstatistics tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
       });
       });
      });
</script>


<!--vider la table-->
<script>
    $(document).ready(function(){
        $('#delete_table_btn').click(function(e){
        
        e.preventDefault();
        $("#deleteStatistics").modal("show");
/*
        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"<?php echo e(route('deleteAllTable')); ?>",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   alert("success");

                },
                error:function(error){
                  alert("error");
                }
              });  */
      })

      $('#delete').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"<?php echo e(route('deleteAllTable')); ?>",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
      /*           $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "<?php echo e(route('globstatsview')); ?>";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })





      });
</script>
           
<!--ajouter les nom des fichier dans la balise ul-->
<script>
$(document).ready(function(){
   /* $("#filenamescontent")css('visibility','hidden');
    if ($('#filenames li').length > 1){
       alert("test");
    } */

    $.get("<?php echo e(route('importedfiles')); ?>", function(data, response){
                //alert(data[0].nom_fichier);
                for (var i = 0; i < data.length; i++) {
                    if(data[i].type_fichier == "age_reel"){
                        var line=' <li class="list-group-item list-group-item-success">'+data[i].nom_fichier+'</li>';
                    $('#filenames').append(line);
                    }       
                }
              
            });



//delete2 
$('#zero_ram').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"<?php echo e(route('deleteAllTable')); ?>",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "<?php echo e(route('zeroramview')); ?>";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })


      $('#tac_ram').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"<?php echo e(route('deleteAllTable')); ?>",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "<?php echo e(route('tacramview')); ?>";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })



      $('#f_passage').click(function(e){
        
        e.preventDefault();
       

        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"<?php echo e(route('deleteAllTable')); ?>",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "<?php echo e(route('passageview')); ?>";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })


      $('#f_globale').click(function(e){
        
        e.preventDefault();
       
        $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"delete",
                url:"<?php echo e(route('deleteAllTable')); ?>",
                success:function(data,response){
                   $('#tabstatistics').html('');
                   $(".modal").modal('hide');
                 //  alert("success");
           /*      $('#success_modal').modal('show');

                 setTimeout(function() {
                 $('#success_modal').modal('hide');
                 }, 2000); */
                 window.location = "<?php echo e(route('globstatsview')); ?>";

                },
                error:function(error){
                  alert("error");
                }
              });  
      })


      });
</script>



<!--Afficher le modal exportexcel-->
<script>
    $(document).ready(function(){
      $("#exportfile").click(function(){
        $("#exportexcelfile_modal").modal("show");
      })
      });
</script>


<!--declencher un evenement apres le clique sur la ligne-->
<script>
    $(document).ready(function(){
    
      $(document).on("click", ".clickabletr" , function() {
          $tr=$(this).closest('tr');
          var data=$tr.children("td").map(function(){
          return $(this).text();
          }).get();

          $("#id_client").val(data[0]);
          $(".nom_client").text(data[2]);
          
          $("#updatenullage_modal").modal("show");
         
    })


    /////////////////
    $('#update_age_client').click(function(e){
                  e.preventDefault();
                  var id=$('#id_client').val();
                  var age=$('#age_reel_client').val();
                // alert(age);
                  var newDate={
                      id_client:id,
                      age_client:age,
                  }                
                 $.ajax({
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                     type:"PUT",
                     url:"/updateClientAgeReel",
                     data:newDate,
                     success:function(data,response){
                        $('#tabstatistics').html("");
                       $(".modal").modal('hide');
                       $('#success_modal').modal('show');

                     setTimeout(function() {
                     $('#success_modal').modal('hide');
                     }, 2000);

                     for (var i = 0; i < data.length; i++) {
                        var line='';
                        if(data[i].age_reel == null){
                            line='<tr class="'+data[i].id+' clickabletr" style="background-color:rgb(231, 161, 176)"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].commercial+'</td><td>'+data[i].client+'</td><td>'+data[i].age_reel+'</td><td>'+data[i].age_avec_0ramassage+'</td><tr/>';
                        }else{
                            line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].commercial+'</td><td>'+data[i].client+'</td><td>'+data[i].age_reel+'</td><td>'+data[i].age_avec_0ramassage+'</td><tr/>';
                        }
                       
                        $('#tabstatistics').append(line);
                     }
                         $('#id_client').val("")
                         $('#age_reel_client').val("");
                     },
                     error:function(error){
                         alert("echec de modification");
                     }
                 }); 
              }); 
    ////////////////

    });

    </script>





<script>
    $(document).ready(function(){
        $('#editform2').on('submit',function(e){
              e.preventDefault();
              var totalFormData=new FormData($('#editform2')[0]);
              totalFormData.append('_method', 'put');
             // alert(totalFormData.modpassword);

             $.ajax({
                 type:"POST",
                 url:"<?php echo e(route('updateuser2')); ?>",
                 processData: false,
                 contentType: false,
                 data:totalFormData,
                // data:$(this).serialize(),
                 success:function(data,response){
                     $('#modpassword2').val('');
                     $('#modimage2').val('');
                    $('#changesettingsModal').modal('hide'); 

                    $('#success_modal').modal('show');

                     setTimeout(function() {
                         $('#success_modal').modal('hide');
                     }, 2000);
                     location.reload();
                     //window.location = "<?php echo e(route('globstats3view')); ?>";
                 },
                 error:function(error){
                  alert("Erreur");
                 }
             });
          });
    });
    </script>


</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ramex\project\resources\views/showglobstats2.blade.php ENDPATH**/ ?>