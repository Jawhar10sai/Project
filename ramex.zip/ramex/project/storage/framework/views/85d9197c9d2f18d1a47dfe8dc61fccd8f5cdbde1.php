<?php
use App\Models\Droit;
$droits=Droit::where('profil',Auth::user()->profil)->get();
//dd($droits[0]->profil);
?>




<?php $__env->startSection('content'); ?>
                <!--my table begin-->
               
                <?php if($droits[0]->add_client == 1): ?>
                <button type="submit" class="btn btn-primary addclient"  href="#" data-toggle="modal" ><i class="fas fa-plus" style="margin-right:5px"></i>Nouveau client</button>
                <?php endif; ?>
                
                <div class="row">
            <div class="col-md-12">
                <div class="form-content">    

           <h3 class="text-center">Liste des clients</h3>


            <!--searchbar-->
            <div class="container input-group rounded" style="margin-bottom:7px;padding-left:80px;padding-right:80px">
                <input type="search" id="secsearchbar" class="form-control rounded" placeholder="Que cherchez-vous ? " aria-label="Search" aria-describedby="search-addon"/>
                <button class="btn btn-primary" style="border-top-right-radius:20px;border-bottom-right-radius:20px;border-top-left-radius:0px;border-bottom-left-radius:0px"  disabled>
                  <i class="fas fa-search"></i>
                </button>
              </div>
                    

    
           <table class="table">
           <thead class="thead thead-dark ">
             <tr>
             <th>CODE</th>
             <th>NOM</th>
             <th>AGENCE</th>
             <th>SECTEUR</th>
         <!--    <th>COMMERCIAL</th> -->
             <th>NUM TEL</th>
             <th>ADRESSE</th>
             <?php if($droits[0]->update_client == 1 || $droits[0]->delete_client == 1): ?>
             <th>ACTION</th>
             <?php endif; ?>
             </tr>
             </thead>
             <tbody id="tabclients">
           
             </tbody>
           </table>
        </div>
        </div>
                </div>
<!--my table end-->

                 <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Ramex 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

          

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
               
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/logout.jpg')); ?>" alt="" style="width:130px;height:130px"></div>
                        <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h5>voulez-vous vraiment vous déconnecter ?</h5></center></div>
                    </div>

                    
                     <center>  
                        <a class="btn btn-primary " href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Se Déconnecter')); ?></a>
                                            <button class="btn btn-secondary " type="button" data-dismiss="modal">Quitter</button>
                                        </center>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    
                </div>
                
            </div>
        </div>
    </div>


    <!--success modal begin-->
        <!-- Modal -->
        <div class="modal fade" id="success_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document" >
              <div class="modal-content" style="background-color:rgb(35, 220, 61);border-radius:40px;color:white">
                <div class="modal-body" >
               
                  <div class="row">
                      <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/check.gif')); ?>" alt=""></div>
                      <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Cette opération est terminée avec succès</h3></center></div>
                  </div>
                
                </div>
    
              </div>
            </div>
          </div>
      <!--susccess modal end-->




       <!--delete user modal-->
    <div class="modal fade" id="deleteClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color:#ff0f0f;border-radius:20px;color:white;height:250px"> 

            <form id="deleteFormID">
             <div class="modal-body"> 
             <?php echo e(csrf_field()); ?>

             <?php echo e(method_field('delete')); ?>

             <input type="hidden" name="iddelclient" id="iddelclient" value="">
             <div class="row">
                <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/warning.gif')); ?>" alt="" style="width:150px;height:150px"></div>
                <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Voulez vous vraiment supprimer ce client?</h3></center></div>
            </div>
        <!--     <i class="fas fa-exclamation-triangle" style="font-size:30px; color:#ffcc00"></i> Voulez vous vraiment supprimer cet utilisateur? -->
        <center>
            <button type="submit" id="delete" class="btn btn-danger btn-lg" >Supprimer</button>
            <button class="btn btn-secondary btn-lg" type="button" data-dismiss="modal">Quitter</button>
            </center>   
    </div>
           
            
            </form>
            
        </div>
    </div>
</div>


   


 <!--add client modal begin-->
    
<!-- Modal -->
<div class="modal fade" id="addClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#4e73df;color:white">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter un nouveau client</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="color:white">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!--begin of my form-->
        <div class="col-lg-12">
    
                    <form id="addClientForm" class="user" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <input id="date_de_creation" name="date_de_creation" type="hidden" value="">
                     <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <input id="code_client" type="hidden" class="form-control form-control-user <?php $__errorArgs = ['code_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="code_client" value="<?php echo e(old('code_client')); ?>" placeholder="Code Client">
                                <small id="code_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>

                     <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <input id="nom_client" type="text" class="form-control form-control-user <?php $__errorArgs = ['nom_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="nom_client" value="<?php echo e(old('nom_client')); ?>" placeholder="Nom Client" autocomplete="nom_client">
                                <small id="nom_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                              <select class="form-control <?php $__errorArgs = ['agence_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="agence_client"
                                name="agence_client" value="<?php echo e(old('agence_client')); ?>" style="border-radius:10rem;font-size:.9rem;"  >
                                
                              </select>
                              <small id="agence_client_error" class="form-text text-danger"></small>
                            </div>
                      </div>
        
                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <select class="form-control <?php $__errorArgs = ['secteur_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="secteur_client"
                                  name="secteur_client" value="<?php echo e(old('secteur_client')); ?>" style="border-radius:10rem;font-size:.9rem;"  >
                                <option value="" selected disabled>--Select SECTEUR--</option>
                                </select>
                                <small id="secteur_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>
          <!--
                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                              <select class="form-control <?php $__errorArgs = ['commercial_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="commercial_client"
                               name="commercial_client" value="<?php echo e(old('commercial_client')); ?>" style="border-radius:10rem;font-size:.9rem;">
                                <option value="" selected disabled>--Select COMMERCIAL--</option>
                              </select>
                              <small id="commercial_client_error" class="form-text text-danger"></small>
                            </div>
                        </div> -->


                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <input id="num_tel_client" type="tel"  pattern="[0-9]"  maxlength="10" class="form-control form-control-user <?php $__errorArgs = ['num_tel_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="num_tel_client" value="<?php echo e(old('num_tel_client')); ?>" placeholder="Exemple: 0636363636">
                                <small id="num_tel_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>


                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <textarea id="adresse_client" rows="3" class="form-control form-control-user <?php $__errorArgs = ['adresse_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="adresse_client" value="<?php echo e(old('adresse_client')); ?>" placeholder="Adresse" autocomplete="adresse_client"></textarea>
                                <small id="adresse_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>
                        
                      <center>  
                        <button type="submit" id="save" class="btn btn-primary">Enregistrer </button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Quitter</button>
                     </center>
                    </form>
                
            </div>
        <!--end of my form-->
      </div>
    </div>
  </div>
</div>
    <!--add modal end-->


    <!--edit client modal begin-->
<!-- Modal -->
<div class="modal fade" id="editClient" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#4e73df; color:white">
        <h5 class="modal-title" id="exampleModalLabel">Modifier un client</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="color:white">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!--begin of my form-->
        <div class="col-lg-12">
    
                    <form id="editform" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <?php echo e(method_field('PUT')); ?>

                     <input type="hidden" name="id" id="id">
                     <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <input id="modnom_client" type="text" class="form-control form-control-user <?php $__errorArgs = ['nom_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="modnom_client" value="<?php echo e(old('nom_client')); ?>" style="border-radius:10rem;font-size:.9rem;" placeholder="Nom Client" autocomplete="nom_client" required>
                                <small id="modnom_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>

                        
                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                              <select class="form-control <?php $__errorArgs = ['agence_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="modagence_client"
                                name="modagence_client" value="<?php echo e(old('agence_client')); ?>" style="border-radius:10rem;font-size:.9rem;"  >
                                <option value="" disabled>--Select AGENCE--</option>
                              </select>
                              <small id="modagence_client_error" class="form-text text-danger"></small>
                            </div>
                      </div>
        
                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <select class="form-control <?php $__errorArgs = ['secteur_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="modsecteur_client"
                                  name="modsecteur_client" value="<?php echo e(old('secteur_client')); ?>" style="border-radius:10rem;font-size:.9rem;"  >
                                <option value="" disabled>--Select SECTEUR--</option>
                                </select>
                                <small id="modsecteur_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>
          
                        <!--
                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                              <select class="form-control <?php $__errorArgs = ['commercial_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="modcommercial_client"
                               name="modcommercial_client" value="<?php echo e(old('commercial_client')); ?>" style="border-radius:10rem;font-size:.9rem;">
                                <option value="" selected disabled>--Select COMMERCIAL--</option>
                              </select>
                              <small id="modcommercial_client_error" class="form-text text-danger"></small>
                            </div>
                        </div> -->


                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                              <input type="text" id="modnum_tel_client" maxlength="10" class="form-control form-control-user <?php $__errorArgs = ['num_tel_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               name="modnum_tel_client" value="<?php echo e(old('num_tel_client')); ?>" style="border-radius:10rem;font-size:.9rem;">
                               
                              </select>
                              <small id="modcommercial_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>


                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <textarea id="modadresse_client" rows="3" class="form-control form-control-user <?php $__errorArgs = ['adresse_client'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                 name="modadresse_client" value="<?php echo e(old('adresse_client')); ?>" placeholder="Adresse" autocomplete="adresse_client" required ></textarea>
                                <small id="modadresse_client_error" class="form-text text-danger"></small>
                            </div>
                        </div>
        
                      <center>
                        <button type="submit" class="btn btn-primary">Enregistrer </button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Quitter</button>
                    </center>
                    </form>
                
            </div>
        <!--end of my form-->
      </div>
    </div>
  </div>
</div>
    <!--edit user modal end-->


      <!--edit user modal begin-->
<!-- Modal -->
<div class="modal fade" id="changesettingsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#4e73df; color:white">
          <h5 class="modal-title" id="exampleModalLabel">Modifier votre paramètres</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color:white">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!--begin of my form-->
          <div class="col-lg-12">
      
                      <form id="editform2" enctype="multipart/form-data">
                       <?php echo csrf_field(); ?>
                       <?php echo e(method_field('PUT')); ?>

                       
                          <div class="form-group">
                                  <label for="">Changer votre image de profil</label>
                                  <input id="modimage2" type="file" class="form-control"
                                   name="modimage2">
                          </div>
  
                         
  
                          <div class="form-group">
                            <label for="">Changer votre mot de passe</label>
                                   <input id="modpassword2" type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="modpassword2" placeholder="Nouveau mot de passe" autocomplete="Nouveau mot de passe">
                                    <small id="modpassword_error" class="form-text text-danger"></small>
                          </div>
  
                        <center>
                          <button type="submit" class="btn btn-primary">Enregistrer </button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                        </center>
                      </form>
                  
              </div>
          <!--end of my form-->
        </div>
      </div>
    </div>
  </div>
      <!--edit user modal end-->

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('customAuth/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customAuth/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('customAuth/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('customAuth/js/sb-admin-2.min.js')); ?>"></script>


<!--Affichage dans la table-->
<script>
$(document).ready(function(){
    $.get("<?php echo e(route('clients')); ?>", function(data, response){
                 var update_client = '<?php echo e($droits[0]->update_client); ?>';
                 var delete_client = '<?php echo e($droits[0]->delete_client); ?>';                 
               // alert(delete_client);

                for (var i = 0; i < data.length; i++) {
                  if(update_client == 1 && delete_client == 1){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                  } else if(update_client == 1 && delete_client == 0){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></td><tr/>';
                  } else if(update_client == 0 && delete_client == 1){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                  }else{
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><tr/>';
                  }
                    $('#tabclients').append(line);
                }

            });
});
</script>







<!--addclient ajax code-->
<script>
        $(document).ready( function(){



            //show add modal
            $(document).on("click", ".addclient" , function() {
            
                $('#addClient').modal('show');

            //code client
            url_code_client="<?php echo e(route('codeClient')); ?>";
            $.get( url_code_client , function(data, response){
               $("#code_client").val(data);
            })
            
            //current date
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth()+1; //January is 0!
            var yyyy = today.getFullYear();
            var hh=today.getHours();
            var mn=today.getMinutes();

             if(dd<10) {
             dd = '0'+dd
              } 
 
             if(mm<10) {
             mm = '0'+mm
              } 

             today = dd + '/' + mm + '/' + yyyy;
             var time = hh +':' + mn;
             $('#date_de_creation').val(today);
             });


                   //select agences
                   $.get("<?php echo e(route('AllAgences')); ?>", function(data, response){
                
                for (var i = 0; i < data.length; i++) {
                    $('#agence_client').append('<option value="'+data[i].nom_agence+'">'+data[i].nom_agence+'</option>');
                    $('#modagence_client').append('<option value="'+data[i].nom_agence+'">'+data[i].nom_agence+'</option>');
                }
            })
            //select sectors
          //  $('#agence_client').change( function(){
            
            var url_ = "<?php echo e(route('AllSectors')); ?>";
            var agence=$('#agence_client').val();
            //alert(agence);
            $('#secteur_client').html('');
            $('#commercial_client').html('');
            $('#commercial_client').append('<option value="" disabled selected>--SELECT COMMERCIAL--</option>');
            $.get( url_ , {ag:agence} , function(data, response){
            var options=''; 
            var default_option='<option value="" disabled selected>--SELECT SECTEUR--</option>';   
            for (var i = 0; i < data.length; i++) {
            options= options +'<option value="'+data[i].nom_secteur+'">'+data[i].nom_secteur+'</option>';
            //$('#secteur_client').append('<option value="'+data[i].nom_secteur+'">'+data[i].nom_secteur+'</option>');
             }
             var secteurs=default_option+options;
             $('#secteur_client').append(secteurs);
            })
         //   });


            //select commercial (useless in this view)
            $('#secteur_client').change( function(){
            
            var url_ = "<?php echo e(route('AllCommercials')); ?>";
            var secteur=$(this).val();
           // alert(secteur);
            $('#commercial_client').html('');
            $.get( url_ , {sec:secteur} , function(data, response){
              //var name= data[0].nom_commercial;
             // alert(name);
             var options='';
             var default_option='<option value="" disabled selected>--SELECT COMMERCIAL--</option>';
            for (var i = 0; i < data.length; i++) {
                options = options + '<option value="'+data[i].nom_commercial+'">'+data[i].nom_commercial+'</option>';
           // $('#commercial_client').append('<option value="'+data[i].nom_commercial+'">'+data[i].nom_commercial+'</option>');
             }
             var commerciaux = default_option + options;
             $('#commercial_client').append(commerciaux);
            }) 

            });



            //select mod sectors for mod modal
            $('#modagence_client').change( function(){
            
            var url_ = "<?php echo e(route('AllSectors')); ?>";
            var agence=$('#modagence_client').val();
            //alert(agence);
            $('#modsecteur_client').html('');
            $('#commercial_client').append('<option value="" disabled selected>--SELECT COMMERCIAL--</option>');
            $.get( url_ , {ag:agence} , function(data, response){
            for (var i = 0; i < data.length; i++) {
            $('#modsecteur_client').append('<option value="'+data[i].nom_secteur+'">'+data[i].nom_secteur+'</option>');
             }
            })
            }); 


                //select mod commercial
            $('#modsecteur_client').change( function(){
            
            var url_ = "<?php echo e(route('AllCommercials')); ?>";
            var secteur=$(this).val();
           // alert(secteur);
            $('#modcommercial_client').html('');
            $.get( url_ , {sec:secteur} , function(data, response){
              //var name= data[0].nom_commercial;
             // alert(name);
             var options='';
             var default_option='<option value="" disabled selected>--SELECT COMMERCIAL--</option>';
            for (var i = 0; i < data.length; i++) {
                options = options + '<option value="'+data[i].nom_commercial+'">'+data[i].nom_commercial+'</option>';
           // $('#commercial_client').append('<option value="'+data[i].nom_commercial+'">'+data[i].nom_commercial+'</option>');
             }
             var commerciaux = default_option + options;
             $('#modcommercial_client').append(commerciaux);
            }) 

            });
  

            //submit
            $('#save').on('click',function(e){
              e.preventDefault();
              //var totalFormData=new FormData($('#addform')[0]);
              $.ajax({
                type:"POST",
                url:"<?php echo e(route('storeclient')); ?>",
                data:$('#addClientForm').serialize(),
                success:function(data,response){
                   // alert('Client a été ajouté avec succes');
                    $('#addClient').modal('hide');

                    $('#success_modal').modal('show');

                      setTimeout(function() {
                          $('#success_modal').modal('hide');
                      }, 2000);

                    $('#code_client').val('');
                    $('#nom_client').val('');
                    $('#agence_client').val('');
                    $('#secteur_client').val('');
                    $('#commercial_client').val('');
                    $('#num_tel_client').val('');
                    $('#adresse_client').val('');
                    $('#date_de_creation').val('');

                    $("#tabclients").html('');

                    //console.log(response);
                    //$('#addUser').modal('hide');
                     //alert(data.code_client);
/**********/
                 var update_client = '<?php echo e($droits[0]->update_client); ?>';
                 var delete_client = '<?php echo e($droits[0]->delete_client); ?>';                 
               // alert(delete_client);
                for (var i = 0; i < data.length; i++) {
                  if(update_client == 1 && delete_client == 1){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                  } else if(update_client == 1 && delete_client == 0){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></td><tr/>';
                  } else if(update_client == 0 && delete_client == 1){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                  }else{
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><tr/>';
                  }
/**********/
                      $('#tabclients').append(line);
                     }
                     /*add one line*/
                 //   var newline='<tr class="'+data.id+'"><td style="display:none;">'+data.id+'</td><td>'+data.code_client+'</td><td>'+data.nom_client+'</td><td>'+data.agence_client+'</td><td>'+data.secteur_client+'</td><td>'+data.commercial_client+'</td><td>'+data.adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                 //   $('#tabclients').append(newline);  
                   // alert('Utilisateur a été ajouté avec succes');
                    //location.reload();
                },
                error:function(error){
                  //  alert('erreur');
                    $("#code_client_error").text("");
                    $("#nom_client_error").text("");
                    $("#agence_client_error").text("");
                    $("#secteur_client_error").text("");
                    $("#commercial_client_error").text("");
                    $("#adresse_client_error").text("");
                
                    //console.log(error);
                    var response=$.parseJSON(error.responseText);
                    //alert(response.errors);
                    $.each(response.errors,function(key,val){
                       $("#"+key+"_error").text(val[0]);
                    }); 
                }
              });
            });


        });
    </script>

    <!--Search bar-->
           <script>
           $(document).ready(function(){
           $("#searchbar").on("keyup", function() {
             var value = $(this).val().toLowerCase();
           $("#tabclients tr").filter(function() {
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
            });
            });
            </script>

    <!-- Second Search bar-->
           <script>
            $(document).ready(function(){
            $("#secsearchbar").on("keyup", function() {
              var value = $(this).val().toLowerCase();
            $("#tabclients tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
             });
             });
             });
             </script>

     <!--modCLIENT ajax code-->       
     <script>
           $(document).ready(function(){
           
            $(document).on("click", "a.editbtn" , function() {
            $('#editClient').modal('show');

            $tr=$(this).closest('tr');
            var data=$tr.children("td").map(function(){
                return $(this).text();
            }).get();
           // alert(data);

            $('#id').val(data[0]);
            //$('#code_client').val(data[1]);
            $('#modnom_client').val(data[2]);
            $('#modagence_client option').attr('selected', false);
            $('#modagence_client option[value="'+data[3]+'"]').attr('selected', true);

            //code secteur
                  var url_ = "<?php echo e(route('AllSectors')); ?>";
                  var agence=data[3];
                  //alert(agence);
                  $('#modsecteur_client').html('');
                  var selected='';
                  var sec=data[4];
                  $.get( url_ , {ag:agence} , function(data, response){
                  for (var i = 0; i < data.length; i++) {
                    //alert(data[i].nom_secteur+' '+ sec); 
                    if(data[i].nom_secteur == sec){
                        selected='<option value="'+data[i].nom_secteur+'" selected>'+data[i].nom_secteur+'</option>';
                      }
                      else{
                          selected='<option value="'+data[i].nom_secteur+'">'+data[i].nom_secteur+'</option>';
                      }
                      $('#modsecteur_client').append(selected);
                    //if(data[i].nom_secteur == data[4]){'selected="selected"'}
                 // $('#modsecteur_client').append('<option '++' value="'+data[i].nom_secteur+'">'+data[i].nom_secteur+'</option>');
                  }
                  }) 
                 //code commercial
                 var url_2 = "<?php echo e(route('AllCommercials')); ?>";
                  var secteur=data[4];
                  //alert(agence);
                  $('#modcommercial_client').html('');
                  var selected2='';
                  var com=data[5];
                  $.get( url_2 , {sec:secteur} , function(data, response){
                  for (var i = 0; i < data.length; i++) {
                    //alert(data[i].nom_secteur+' '+ sec); 
                    if(data[i].nom_commercial == com){
                        selected2='<option value="'+data[i].nom_commercial+'" selected>'+data[i].nom_commercial+'</option>';
                      }
                      else{
                          selected2='<option value="'+data[i].nom_commercial+'">'+data[i].nom_commercial+'</option>';
                      }
                      $('#modcommercial_client').append(selected2);
                    //if(data[i].nom_secteur == data[4]){'selected="selected"'}
                 // $('#modsecteur_client').append('<option '++' value="'+data[i].nom_secteur+'">'+data[i].nom_secteur+'</option>');
                  }
                  }) 

                  $('#modnum_tel_client').val(data[5]);
                  $('#modadresse_client').val(data[6]);
                   

              });
              
              $('#editform').on('submit',function(e){
                  e.preventDefault();

                 $.ajax({
                     type:"POST",
                     url:"<?php echo e(route('updateClient')); ?>",
                     data:$(this).serialize(),
                     success:function(data,response){
                        $('#editClient').modal('hide'); 

                        $('#success_modal').modal('show');

                          setTimeout(function() {
                              $('#success_modal').modal('hide');
                          }, 2000);
                       // alert("Utilisateur a été modifié avec succes");
                        //location.reload();
                       // $("."+data.id).remove();
                      //  var line='<tr class="'+data.id+'"><td style="display:none;">'+data.id+'</td><td>'+data.code_client+'</td><td>'+data.nom_client+'</td><td>'+data.agence_client+'</td><td>'+data.secteur_client+'</td><td>'+data.commercial_client+'</td><td>'+data.adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                      //  $('#tabclients').append(line);
                      $("#tabclients").html('');
                      /**********/
                 var update_client = '<?php echo e($droits[0]->update_client); ?>';
                 var delete_client = '<?php echo e($droits[0]->delete_client); ?>';                 
               // alert(delete_client);
                for (var i = 0; i < data.length; i++) {
                  if(update_client == 1 && delete_client == 1){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                  } else if(update_client == 1 && delete_client == 0){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></td><tr/>';
                  } else if(update_client == 0 && delete_client == 1){
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><td><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                  }else{
                    var line='<tr class="'+data[i].id+'"><td style="display:none;">'+data[i].id+'</td><td>'+data[i].code_client+'</td><td>'+data[i].nom_client+'</td><td>'+data[i].agence_client+'</td><td>'+data[i].secteur_client+'</td><td>'+data[i].num_tel+'</td><td>'+data[i].adresse_client+'</td><tr/>';
                  }
/**********/
                      $('#tabclients').append(line);
                     }
                     },
                     error:function(error){
                         alert("echec de modification");
                     }
                 });
              }); 
             

            });
            </script>

            <!--delete client ajax code-->       
     <script>
           $(document).ready(function(){
            $(document).on("click", "a.delbtn" , function() {
            $('#deleteClient').modal('show');

            $tr=$(this).closest('tr');
            var data=$tr.children("td").map(function(){
                return $(this).text();
            }).get();

            $('#iddelclient').val(data[0]);
              });

              $('#deleteFormID').on('submit',function(e){
               e.preventDefault();
               var id=$('#iddelclient').val();

               $.ajax({
                     type:"delete",
                     url:"<?php echo e(route('deleteClient')); ?>",
                     data:$(this).serialize(),
                     success:function(data,response){
                        $('#deleteClient').modal('hide');
                        $('#success_modal').modal('show');

                          setTimeout(function() {
                              $('#success_modal').modal('hide');
                          }, 2000); 

                        //alert("Utilisateur a été modifié avec succes");
                        //location.reload();
                        //$("#tabusers").children().remove();
                        $("."+data.id).remove();
                     },
                     error:function(error){
                        alert(error);
                     }
                 });

              })

            });
            </script>

            
    <script>
        $(document).ready(function(){
            $('#editform2').on('submit',function(e){
                  e.preventDefault();
                  var totalFormData=new FormData($('#editform2')[0]);
                  totalFormData.append('_method', 'put');
                 // alert(totalFormData.modpassword);

                 $.ajax({
                     type:"POST",
                     url:"<?php echo e(route('updateuser2')); ?>",
                     processData: false,
                     contentType: false,
                     data:totalFormData,
                    // data:$(this).serialize(),
                     success:function(data,response){
                         $('#modpassword2').val('');
                         $('#modimage2').val('');
                        $('#changesettingsModal').modal('hide'); 

                        $('#success_modal').modal('show');

                         setTimeout(function() {
                             $('#success_modal').modal('hide');
                         }, 2000);
                         location.reload();
                         //window.location = "<?php echo e(route('globstats3view')); ?>";
                     },
                     error:function(error){
                      alert("Erreur");
                     }
                 });
              });
        });
        </script>

</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ramex\project\resources\views/showClients.blade.php ENDPATH**/ ?>