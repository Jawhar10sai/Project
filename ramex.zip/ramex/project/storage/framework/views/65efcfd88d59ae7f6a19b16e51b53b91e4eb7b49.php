

<?php $__env->startSection('content'); ?>
                <!--my table begin-->
                <button type="submit" class="btn btn-primary"  href="#" data-toggle="modal" data-target="#addMotif"><i class="fas fa-plus" style="margin-right:5px"></i>Nouveau motif</button>
            
                <div class="row" style="margin-top:80px">
            <div class="col-md-12">
                
                <div class="form-content" >    

           <h3 class="text-center">Liste des motifs</h3>

             <!--searchbar-->
             <div class="container input-group rounded" style="margin-bottom:7px;padding-left:80px;padding-right:80px">
                <input type="search" id="secsearchbar" class="form-control rounded" placeholder="Que cherchez-vous ? " aria-label="Search" aria-describedby="search-addon"/>
                <button class="btn btn-primary" style="border-top-right-radius:20px;border-bottom-right-radius:20px;border-top-left-radius:0px;border-bottom-left-radius:0px"  disabled>
                  <i class="fas fa-search"></i>
                </button>
              </div>
        
    
           <table class="table" >
           <thead class="thead thead-dark ">
             <tr>
             <th hidden>ID-Motif</th>
             <th>Motif</th>
             <th>ACTION</th>
             </tr>
             </thead>
             <tbody id="tabmotifs">
           
             </tbody>
           </table>
           
        </div>
    
        </div>

    </div>
<!--my table end-->

         <!-- Footer -->
         <footer class="sticky-footer bg-white">
           <div class="container my-auto">
               <div class="copyright text-center my-auto">
                   <span>Copyright &copy; Ramex 2021</span>
               </div>
           </div>
         </footer>
        <!-- End of Footer -->

                </div>
                <!-- /.container-fluid -->
            
            </div>
            <!-- End of Main Content -->

 

          

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
               
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/logout.jpg')); ?>" alt="" style="width:130px;height:130px"></div>
                        <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h5>voulez-vous vraiment vous déconnecter ?</h5></center></div>
                    </div>

                    
                     <center>  
                        <a class="btn btn-primary " href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                         document.getElementById('logout-form').submit();">
                                            <?php echo e(__('Se Déconnecter')); ?></a>
                                            <button class="btn btn-secondary " type="button" data-dismiss="modal">Quitter</button>
                                        </center>
                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                    
                </div>
                
            </div>
        </div>
    </div>




     <!--success modal begin-->
        <!-- Modal -->
        <div class="modal fade" id="success_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document" >
              <div class="modal-content" style="background-color:rgb(35, 220, 61);border-radius:40px;color:white">
                <div class="modal-body" >
               
                  <div class="row">
                      <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/check.gif')); ?>" alt=""></div>
                      <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Cette opération est terminée avec succès</h3></center></div>
                  </div>
                
                </div>
    
              </div>
            </div>
          </div>
      <!--susccess modal end-->

    


       <!--delete motif modal-->
    <div class="modal fade" id="deleteMotif" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" style="background-color:#ff0f0f;border-radius:20px;color:white;height:250px"> 

            <form id="deleteFormID">
             <div class="modal-body"> 
             <?php echo e(csrf_field()); ?>

             <?php echo e(method_field('delete')); ?>

             <input type="hidden" name="iddelmotif" id="iddelmotif" value="">
             <div class="row">
                <div class="col-md-4"> <img src="<?php echo e(asset('customAuth/images/warning.gif')); ?>" alt="" style="width:150px;height:150px"></div>
                <div class="col-md-8" style="padding-top:50px;padding-left:50px"><center><h3>Voulez vous vraiment supprimer ce motif?</h3></center></div>
            </div>
        <!--     <i class="fas fa-exclamation-triangle" style="font-size:30px; color:#ffcc00"></i> Voulez vous vraiment supprimer cet utilisateur? -->
        <center>
            <button type="submit" id="delete" class="btn btn-danger btn-lg" >Supprimer</button>
            <button class="btn btn-secondary btn-lg" type="button" data-dismiss="modal">Quitter</button>
            </center>   
    </div>
           
            
            </form>
            
        </div>
    </div>
</div>




 <!--add Motif modal begin-->
    
<!-- Modal -->
<div class="modal fade" id="addMotif" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#4e73df;color:white">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter un nouveau motif</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="color:white">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!--begin of my form-->
        <div class="col-lg-12">
    
                    <form id="addform" class="motif" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>


                        <div class="form-group row">
                            <div class="col-sm-12 mb-3 mb-sm-0">
                                <input id="motif" type="text" class="form-control"
                                 name="motif" value="<?php echo e(old('motif')); ?>" placeholder="Veuillez entrer un motif" autocomplete="motif">
                                <small id="motif_error" class="form-text text-danger"></small>
                            </div>
                        </div>
                      <center> 
                          <button type="submit" id="save" class="btn btn-primary">Ajouter </button>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Quitter</button>
                    </center>
                    </form>
                
            </div>
        <!--end of my form-->
      </div>
    </div>
  </div>
</div>
    <!--add modal end-->


    <!--edit motif modal begin-->
<!-- Modal -->
<div class="modal fade" id="editMotif" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header" style="background-color:#4e73df; color:white">
        <h5 class="modal-title" id="exampleModalLabel">Modifier un motif</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" style="color:white">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <!--begin of my form-->
        <div class="col-lg-12">
    
                    <form id="editform" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                     <?php echo e(method_field('PUT')); ?>

                     <input type="hidden" name="id" id="id">
                   

                     <div class="form-group row">
                        <div class="col-sm-12 mb-3 mb-sm-0">
                            <input id="modmotif" type="text" class="form-control"
                             name="modmotif" autocomplete="modmotif" required>
                            <small id="modmotif_error" class="form-text text-danger"></small>
                        </div>
                    </div>             
        
                      <center>
                        <button type="submit" class="btn btn-primary">Modifier </button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Quitter</button>
                        </center>
                    </form>
                
            </div>
        <!--end of my form-->
      </div>
    </div>
  </div>
</div>
    <!--edit user modal end-->



      <!--edit user modal begin-->
<!-- Modal -->
<div class="modal fade" id="changesettingsModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header" style="background-color:#4e73df; color:white">
          <h5 class="modal-title" id="exampleModalLabel">Modifier votre paramètres</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" style="color:white">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <!--begin of my form-->
          <div class="col-lg-12">
      
                      <form id="editform2" enctype="multipart/form-data">
                       <?php echo csrf_field(); ?>
                       <?php echo e(method_field('PUT')); ?>

                       
                          <div class="form-group">
                                  <label for="">Changer votre image de profil</label>
                                  <input id="modimage2" type="file" class="form-control"
                                   name="modimage2">
                          </div>
  
                         
  
                          <div class="form-group">
                            <label for="">Changer votre mot de passe</label>
                                   <input id="modpassword2" type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    name="modpassword2" placeholder="Nouveau mot de passe" autocomplete="Nouveau mot de passe">
                                    <small id="modpassword_error" class="form-text text-danger"></small>
                          </div>
  
                        <center>
                          <button type="submit" class="btn btn-primary">Enregistrer </button>
                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Fermer</button>
                        </center>
                      </form>
                  
              </div>
          <!--end of my form-->
        </div>
      </div>
    </div>
  </div>
      <!--edit user modal end-->




    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo e(asset('customAuth/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('customAuth/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo e(asset('customAuth/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom scripts for all pages-->
    <script src="<?php echo e(asset('customAuth/js/sb-admin-2.min.js')); ?>"></script>
    
    <!--script toastr-->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


<!--Affichage dans la table-->
<script>
$(document).ready(function(){
    $.get("<?php echo e(route('AllMotifs')); ?>", function(data, response){
                
                for (var i = 0; i < data.length; i++) {

                    var line='<tr class="'+data[i].id+'"><td hidden>'+data[i].id+'</td><td>'+data[i].motif+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                    $('#tabmotifs').append(line);
                }
              //  var pagination= data.links;
              //  $('.pag').append(pagination);
            });
});
</script>
<!--addmotif ajax code-->
<script>
        $(document).ready( function(){

            //submit
            $('#save').on('click',function(e){
              e.preventDefault();

              var mydata={
                  motif:$("#motif").val(),
              }
              $.ajax({
                headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                type:"POST",
                url:"<?php echo e(route('storemotif')); ?>",
                data:mydata,
                //data:new FormData($('#addform').serialize()),
                success:function(data,response){
                    //console.log(response);
                    $('#addMotif').modal('hide');
                    $("#motif").val("");
                    $('#tabmotifs').html('');
                    //alert(data.id);
                    for (var i = 0; i < data.length; i++) {
                      var line='<tr class="'+data[i].id+'"><td hidden>'+data[i].id+'</td><td>'+data[i].motif+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                      $('#tabmotifs').append(line);
                    }
                   $('#success_modal').modal('show');

                   setTimeout(function() {
                       $('#success_modal').modal('hide');
                   }, 2000);
                 
                },
                error:function(error){
                    $("#motif_error").text("");
                    var response=$.parseJSON(error.responseText);
                    //alert(response.errors);
                    $.each(response.errors,function(key,val){
                       $("#"+key+"_error").text(val[0]);
                    });
                //  alert("erreur");
                }
              });
            });

          //  public ActionResult IndexAjax() { var data=AddToastMessage("Congratulations", "You made it all the way here!", ToastType.Success); 
        //return Json(data, JsonRequestBehavior.AllowGet);
        });


       
      </script>

    <!--Search bar-->
           <script>
           $(document).ready(function(){
           $("#searchbar").on("keyup", function() {
             var value = $(this).val().toLowerCase();
           $("#tabusers tr").filter(function() {
           $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
            });
            });
            });
            </script>

     <!--modmotif ajax code-->       
     <script>
           $(document).ready(function(){
            
            $(document).on("click", "a.editbtn" , function() {
            $('#editMotif').modal('show');

            $tr=$(this).closest('tr');
            var data=$tr.children("td").map(function(){
                return $(this).text();
            }).get();

            $('#id').val(data[0]);

            $('#modmotif').val(data[1]);

              });
              $('#editform').on('submit',function(e){
                  e.preventDefault();
                  var mydata={
                      id:$('#id').val(),
                      newMotif: $('#modmotif').val(),
                  }
               //   alert($('#modmotif').val());
                 $.ajax({
                     type:"PUT",
                     url:"<?php echo e(route('updatemotif')); ?>",
                     data:mydata,
                     headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    // data:$(this).serialize(),
                     success:function(data,response){
                      //   $('#modmotif').val('');
                        
                        $('#editMotif').modal('hide');
                        $("#tabmotifs").html(""); 
                        for (var i = 0; i < data.length; i++) {
                           var line='<tr class="'+data[i].id+'"><td hidden>'+data[i].id+'</td><td>'+data[i].motif+'</td><td> <a class="btn btn-primary editbtn" href="#" style="margin-right:3px"><i class="fas fa-pen"></i>Modifier</a></button><a class="btn btn-danger delbtn" href="#"  ><i class="fas fa-trash"></i>Supprimer</a></td><tr/>';
                           $('#tabmotifs').append(line);
                        }

                        $('#success_modal').modal('show');

                         setTimeout(function() {
                             $('#success_modal').modal('hide');
                         }, 2000);
                      
                     },
                     error:function(error){
                        $("#modmotif_error").text("");
                          var response=$.parseJSON(error.responseText);
                          //alert(response.errors);
                         $.each(response.errors,function(key,val){
                             $("#"+key+"_error").text(val[0]);
                         });
                       //  alert("echec de modification");
                     }
                 }); 
              });
             

            });
            </script>

            <!--delmotif ajax code-->       
     <script>
           $(document).ready(function(){
            $(document).on("click", "a.delbtn" , function() {
            $('#deleteMotif').modal('show');

            $tr=$(this).closest('tr');
            var data=$tr.children("td").map(function(){
                return $(this).text();
            }).get();

            $('#iddelmotif').val(data[0]);
        /*    $(document).on("click","#delete",function(e){
                e.preventDefault();
                var id=$('#iddeluser').val();
                //alert(id);

                   $.ajax({
                     type:"delete",
                     url:"/delete",
                     data:id,
                    // data:$(this).serialize(),
                     success:function(response){
                        $('#deleteUser').modal('hide'); 
                        alert("Utilisateur a été modifié avec succes");
                        location.reload();
                     },
                     error:function(error){
                         alert("echec de modification");
                     }
                 });

            });*/
              });

              $('#deleteFormID').on('submit',function(e){
               e.preventDefault();
               var id=$('#iddelmotif').val();

               $.ajax({
                     type:"delete",
                     url:"<?php echo e(route('deleteMotif')); ?>",
                     data:$(this).serialize(),
                     success:function(data,response){
                        $('#deleteMotif').modal('hide'); 
                        //alert("Utilisateur a été modifié avec succes");
                        //location.reload();
                        //$("#tabusers").children().remove();
                        $("."+data.id).remove();


                        $('#success_modal').modal('show');
                         setTimeout(function() {
                             $('#success_modal').modal('hide');
                         }, 2000);
                     },
                     error:function(error){
                       alert(error);
                     }
                 });

              })

            });
            </script>

               <!-- Second Search bar-->
           <script>
            $(document).ready(function(){
            $("#secsearchbar").on("keyup", function() {
              var value = $(this).val().toLowerCase();
            $("#tabmotifs tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
             });
             });
             });
             </script>

             
    <script>
        $(document).ready(function(){
            $('#editform2').on('submit',function(e){
                  e.preventDefault();
                  var totalFormData=new FormData($('#editform2')[0]);
                  totalFormData.append('_method', 'put');
                 // alert(totalFormData.modpassword);

                 $.ajax({
                     type:"POST",
                     url:"<?php echo e(route('updateuser2')); ?>",
                     processData: false,
                     contentType: false,
                     data:totalFormData,
                    // data:$(this).serialize(),
                     success:function(data,response){
                         $('#modpassword2').val('');
                         $('#modimage2').val('');
                        $('#changesettingsModal').modal('hide'); 

                        $('#success_modal').modal('show');

                         setTimeout(function() {
                             $('#success_modal').modal('hide');
                         }, 2000);
                         location.reload();
                         //window.location = "<?php echo e(route('globstats3view')); ?>";
                     },
                     error:function(error){
                      alert("Erreur");
                     }
                 });
              });
        });
        </script>

</body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ramex\project\resources\views/showMotifs.blade.php ENDPATH**/ ?>