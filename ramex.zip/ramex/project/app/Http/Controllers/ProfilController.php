<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Profil;
use App\Models\Droit;
use Illuminate\Support\Facades\Auth;

class ProfilController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function showProfils(){  
      $droits=Droit::where('profil',Auth::user()->profil)->get();
      
      if($droits[0]->manage_profils==1){
        return view('showProfils');
       }else{
        return view('error403');
       }
        
    }

      //add profil
      public function store(Request $req){
        $profil=new Droit();
        $profil->profil=$req->profil;
        $profil->show_client=$req->showclient;
        $profil->add_client=$req->addclient;
        $profil->update_client=$req->updateclient;
        $profil->delete_client=$req->deleteclient;
        $profil->show_command=$req->showcommand;
        $profil->add_command=$req->addcommand;
        $profil->update_command=$req->updatecommandbef;
        $profil->update2_command=$req->updatecommandaf;
        $profil->delete_command=$req->deletecommand;
        $profil->assign_command=$req->assigncommand;
        $profil->confirm_command=$req->confirmcommand;
        $profil->cancel_command=$req->cancelcommand;
        $profil->manage_profils=$req->manageprofils;
        $profil->manage_users=$req->manageusers;
        $profil->manage_motifs=$req->managemotifs;
        $profil->manage_agences=$req->manageagences;
        $profil->manage_sectors=$req->managesectors;
        $profil->manage_commercials=$req->managecommercials;
        $profil->users_history=$req->usershistory;
        $profil->clients_history=$req->clientshistory;
        $profil->commands_history=$req->commandshistory;
        $profil->generate_sheets=$req->generatesheets;
        $profil->dashboard=$req->dashboard;
        $profil->save();

        $profils=Droit::orderBy('id','DESC')->get();
        return $profils;
      
       // return $motifs->json(['success' => 'Ajout dun nouveau motif avec succes']);
    }

     //update profil
     public function update(Request $req){

        $profil=Droit::find($req->id);
        $profil->profil=$req->profil;
        $profil->show_client=$req->showclient;
        $profil->add_client=$req->addclient;
        $profil->update_client=$req->updateclient;
        $profil->delete_client=$req->deleteclient;
        $profil->show_command=$req->showcommand;
        $profil->add_command=$req->addcommand;
        $profil->update_command=$req->updatecommandbef;
        $profil->update2_command=$req->updatecommandaf;
        $profil->delete_command=$req->deletecommand;
        $profil->assign_command=$req->assigncommand;
        $profil->confirm_command=$req->confirmcommand;
        $profil->cancel_command=$req->cancelcommand;
        $profil->manage_profils=$req->manageprofils;
        $profil->manage_users=$req->manageusers;
        $profil->manage_motifs=$req->managemotifs;
        $profil->manage_agences=$req->manageagences;
        $profil->manage_sectors=$req->managesectors;
        $profil->manage_commercials=$req->managecommercials;
        $profil->users_history=$req->usershistory;
        $profil->clients_history=$req->clientshistory;
        $profil->commands_history=$req->commandshistory;
        $profil->generate_sheets=$req->generatesheets;
        $profil->dashboard=$req->dashboard;
        $profil->save();

        $profils=Droit::orderBy('id','DESC')->get();
        return $profils;
        
        }

        public function delete(Request $req){
            $profil=Droit::find($req->input('iddelprofil'));
            $profil->delete();
            return $profil;
        }


}
