<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDroitsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('droits', function (Blueprint $table) {
            $table->id();
            $table->string('profil')->nullable();

            $table->integer('show_client')->nullable();
            $table->integer('add_client')->nullable();
            $table->integer('update_client')->nullable();
            $table->integer('delete_client')->nullable();

            $table->integer('show_command')->nullable();
            $table->integer('add_command')->nullable();
            $table->integer('update_command')->nullable();
            $table->integer('update2_command')->nullable();
            $table->integer('delete_command')->nullable();
            $table->integer('assign_command')->nullable();
            $table->integer('confirm_command')->nullable();
            $table->integer('cancel_command')->nullable();

            $table->integer('manage_profils')->nullable();
            $table->integer('manage_users')->nullable();
            $table->integer('manage_motifs')->nullable();
            $table->integer('manage_agences')->nullable();
            $table->integer('manage_sectors')->nullable();
            $table->integer('manage_commercials')->nullable();

            $table->integer('users_history')->nullable();
            $table->integer('clients_history')->nullable();
            $table->integer('commands_history')->nullable();

            $table->integer('generate_sheets')->nullable();
            $table->integer('dashboard')->nullable();





            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('droits');
    }
}
